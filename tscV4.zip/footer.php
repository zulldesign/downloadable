<table border=0 cellspacing=0 cellpadding=0 width="100%" align="center" bgcolor="#cccccc">
	<tr>
		<td>
			<font size=1 color=black>
				<p align="center">Script developed by <a href="http://www.monitor-line.com" target="_blank">Monitor-Line Infoservices Private Limited</a>  </p>
			</font>
		</td>
	</tr>

</table>
