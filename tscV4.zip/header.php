<table border="0" width="100%" cellpadding=10 cellspacing=0 align="center">
  <tr>
    <td nowrap="nowrap" align="left">
			<h2 align="left">PHPStoreCreator application</h2>
			Create your own online store for FREE in minutes...
		</td>
		<td align="center" valign="middle">
			<p>&nbsp;</p>
		</td>
  </tr>
</table>
