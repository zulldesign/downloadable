<table border="0" width="100%" cellpadding=0 cellspacing=0 align="center" bgcolor="#ffcc66">
	<tr>
		<td align="center" valign=top>
			<font size="2">
				:<a href="index.php?a=register">Craete Store Admin Account</a>:
				:<a href="index.php?a=login">Login as Store Admin</a>:
			</font>
		</td>
	</tr>
</table>