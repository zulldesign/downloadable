PHP/MySQL Store Creator with PayPal shopping cart - Readme File
 - By monitor-line Info Services Pvt. Ltd.
***********************************************

Contents:
 - Word from the developer
 - Liabilites
 - Copyright information
 - Contacts
 - Future versions
 - Getting started

-----------------------------------

Word from the developer:

Thank you for downloading our 'PHP/MySQL Store Creator With PayPal Shopping Cart'. We sincerely hope that you will find this a very useful application that will enable you to setup your own online store with little or no hassle.

---------------------------------

Liabilities:

We (author and developer group) of this application DO NOT take any moral, finalcial or any kind of responsibility for the use of this set of files. The user of this application is assumed to have read this clause before using the application.

---------------------------------
Copyright information and License:

You are free to re-use, modify, distribute or resell in any way you want. No restrictions (anyway no one follows them!).

---------------------------------
Contacts:

You can reach the developer team by visiting us at http://www.monitor-line.com

---------------------------------
Future versions:

We are in a process of constantly improving the application and intend to release higher versions periodically. You will be notified whenever a newer version is available.

---------------------------------

Getting started:

Please visit the Installation file to get started.

BEST LUCK!!!!

---------------------------------
