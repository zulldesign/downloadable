<?php
$dbhost = "";   //Host of the DataBase
$dbname = "";   //DB Name
$dbuser = "";   //DB user name
$dbpwd = "";    //DB user password

$baseurl = ""; //URL of your site - http://www.yoursitedomain.com/ (Don't forget the trailing slash '/'
$basepath = ""; //Base path to the root folder of your site - example - /home/somename/public_html/

$sitename= ""; //Give some name to your site


$pagekeywords = ""; //Leave this blank
$pagedesc = ""; //Leave this blank
$pagetitle = ""; //Leave this blank
$pagecontent = ""; //Leave this blank

//No reply email
$noreply_mail = ""; //This is the email which is used as 'From' email. You can use noreply@yourdomain.com - doesn't have to be a valid email if you don't care about the replies to this address. This address will get exposed to the world and is most likely to get spam.

//Service announcements - something you want to send in all email communications
$serviceannouncements = <<<TXT

TXT;

//Admin email
$admin_email = ""; //Use a valid email here. This is where you will get notified for many important messages

//Default email ad - this is sent in all email communcations
$email_adcode = <<<TXT

TXT;

//Banner shown on the stores - save some code like Google adsense or something similar you want to show on each page of your store - note that you can directly edit the template files if you wish to show the banners - be careful though.
$b480X60 = <<<HTM

HTM;

$b120X600 = <<<HTM

HTM;


?>