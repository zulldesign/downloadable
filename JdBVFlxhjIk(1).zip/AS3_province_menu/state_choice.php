<?php 
$theChoice = $_GET['state'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>State Choice From Flash</title>
</head>

<body>
<?php 
print "<br /><br />
<h2>You chose the state of $theChoice.</h2>
<br /><br /><br />
Please press back in you browser.
"; 
?>
</body>
</html>
