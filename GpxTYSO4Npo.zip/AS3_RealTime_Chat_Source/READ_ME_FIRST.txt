This is a tutorial in which you must watch the videos to create the application. 
All of the pieces are in the download package to make life easier for you.

http://www.youtube.com/watch?v=XeWKauwFUEQ

I placed the source code in the download package so you do not
have to try and type the code during video watching.

There are 4 video parts

~Adam Khoury @ www.developphp.com