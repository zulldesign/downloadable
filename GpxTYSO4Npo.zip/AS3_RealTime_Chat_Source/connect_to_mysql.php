<?php 
// place your DB_host, UserName, Password, and DB_Name below where shown
mysql_connect("databaseHost","username","password") or die ("Could not connect.");
mysql_select_db("databaseName") or die ("no database");
?>