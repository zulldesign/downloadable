
There is no support or help offered if you have trouble understanding something.
-----------------------------------------------------------------------------------

This file is for intermediate flash AS3 developers looking to gain understanding
about how to create a complete and compact Photo Gallery.
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------


You can make adjustments to the values in the gallery_config.xml file if needed. 
When you open it and see what it contains you will realize how that file configures
the gallery in flash.
-----------------------------------------------------------------------------------

Open the flash source file to adjust everything, or use the file as it is.
-----------------------------------------------------------------------------------

The ActionScript that loads the XML is in the "xml load" and "thumbnail" movieclip.
-----------------------------------------------------------------------------------
