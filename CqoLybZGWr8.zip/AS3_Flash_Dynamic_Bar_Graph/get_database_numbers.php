<?php
// Script Written By: Adam Khoury @ www.developphp.com
// The variable that Flash sent and defines who we want data returned for
$username = $_POST['username'];
// Connect to your database here
mysql_connect("localhost","db_username_here","db_password_here") or die (mysql_error());
mysql_select_db("db_name_here") or die ("no database");
// Now query the database for the numbers for a particular user
$sql = mysql_query("SELECT experience FROM yourTable WHERE username='$username' LIMIT 1");
while($row = mysql_fetch_array($sql)) { 
    $xpNumber =  $row['experience']; 
}
// Echo the data into Flash Actionscript 3.0 who is waiting patiently
echo "user=$username&xp=$xpNumber";
mysql_close(); // Close the database connection for this script
?>