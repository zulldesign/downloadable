Herro,

There are 3 videos that correspond with these files.

You can search for them if needed at this channel here:
http://www.youtube.com/flashbuilding

-------------------------------------------------------------------------------------

Made for:

Actionscript 3.0
Flash CS3, CS4, CS5

-------------------------------------------------------------------------------------

Made By:

Adam Khoury @ www.flashbuilding.com

(give praise, credit, money, or any virgin women you may have)