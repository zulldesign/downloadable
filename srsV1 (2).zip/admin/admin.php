<?
include_once("../srs_config.php");
include_once("../srs_funs.php");
global $pagecontent, $metatitle, $metadesc;

$link = dbconnect();
$act=$HTTP_GET_VARS['a'];

switch($act)
{
	case "";
		showMainAdmin();
		break;
	case "approveReview";
		$rid = $HTTP_GET_VARS['revid'];
		approveReview($rid);
		break;
	case "approveReview1";
		$rid = $HTTP_POST_VARS['rid'];
		$resultofreview = $HTTP_POST_VARS['outcome'];
		$revcomm = $HTTP_POST_VARS['comment'];
		approveReview1($rid, $resultofreview, $revcomm);
		break;
	case "approveHost";
		$hid = $HTTP_GET_VARS['hid'];
		approveHost($hid);
		break;
	case "approveHost1";
		$hid = $HTTP_POST_VARS['hid'];
		$resultofreview = $HTTP_POST_VARS['outcome'];
		$revcomm = $HTTP_POST_VARS['comment'];
		approveHost1($hid, $resultofreview, $revcomm);
		break;
	case "adjustHost";
		$rid = $HTTP_POST_VARS['revid'];
		$newhost = $HTTP_POST_VARS['hoid'];
		adjustHost($rid, $newhost);
		break;
}
dbclose($link);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
<title><? echo $metatitle; ?></title>
<meta name="description" content="<? echo $metadesc; ?>" />
</head>
<body>
<p><a href="admin.php">Main menu</a></p>
<? echo $pagecontent; ?>
</body>
</html>
<?

//Show main admin screen
function showMainAdmin()
{
	global $pagecontent;
	$pagecontent .= <<<HTM
		:<a href="admin.php?a=approveHost">Approve Site</a>:
		<br>
		:<a href="admin.php?a=approveReview">Approve Review</a>:
HTM;
}

//Approve reviews
function approveReview($revid)
{
	global $pagecontent;
	//Select the list of approved hosts first 
	$q="SELECT id, website_name FROM website WHERE status = 'Y'";
	if($r=mysql_query($q))
	{
		$hostscode .= <<<HTM
			<form action="admin.php?a=adjustHost" method="post">
				<input type="hidden" value="$revid" name="revid">
				<select name="hoid"><option value="-1">Select correct host</option>
				
HTM;
		while($hostsdata = mysql_fetch_array($r))
		{
			$hid = $hostsdata[0];
			$hname = $hostsdata[1];
			$hostscode .= <<<HTM
				<option value="$hid">$hname</option>
HTM;
		}
		$hostscode .= "</select><input type='submit' value='Adjust host'></form>";
	}
	if($revid > 0)
	{
		$q="SELECT * FROM website_review WHERE id = $revid";
	}
	else
	{
		$q="SELECT * FROM website_review ORDER BY id DESC";
	}
	if($r=mysql_query($q))
	{
		while($rdata=mysql_fetch_array($r))
		{
			if($revid)
			{
				$pagecontent .= "<hr>";
				foreach($rdata as $key=>$value)
				{
					if(is_numeric($key))
					{
					}
					else
					{
  					if($key == "id")
  					{
  						$hid = $value;
  					}
					
						if($key == "reviewer_site" and $value != "")
						{
							$urldata = parse_url($value);
							$userdomain = $urldata['host'];
							$whoisurl = "http://whois.domaintools.com/" . $userdomain;
							$value = $value . " -> <a href='$whoisurl' target='_blank'>Check whois</a>";
						}
  					$pagecontent .= <<<HTM
  						<p>$key - $value 
HTM;
						if($key == "website_id")
						{
							//Read the host detains
							$hdataarr = read_host_details($value, "");
							$pagecontent .= " ( " . $hdataarr['website_name'] . " ) ";
							$pagecontent .= " - Adjust host " . $hostscode;
						}
					}
				}
				$pagecontent .= <<<HTM
  				
  					<form action="admin.php?a=approveReview1" method="post">
  						<p>Select review outcome - <select name="outcome">
  						<option value="true">Approve</option>
  						<option value="false">Reject</option>
  						</select>
  						</p>
  						<p>Comment - <input type="text" name="comment" size="50" maxlength="200"></p>
  						<input type="hidden" name="rid" value="$hid">
  						<p><input type="submit" value="Submit"></p>
  					</form>
HTM;


			}
			else
			{
				$siterevid = $rdata['id'];
				$siterevstatus = $rdata['status'];
				if($siterevstatus == "")
				{
					$siterevstatus = "N";
				}
				$siterevstatuscomment = $rdata['reviewcomment'];
				
				$pagecontent.= <<<HTM
					<hr>Review ID -> <a href="admin.php?a=approveReview&revid=$siterevid">$siterevid</a> - Status -> $siterevstatus - Comment -> $siterevstatuscomment
HTM;
			}
		}
	}
}

function approveReview1($rid, $rc, $rcomm)
{
	global $pagecontent, $noreply_email, $sitename, $siteurl;
	$pagecontent .= "<p>Review ID - $rid -> Result - $rc</p>";
	$q="UPDATE website_review SET status = $rc, reviewcomment = '$rcomm' WHERE id = $rid";
	if($r=mysql_query($q))
	{
		$pagecontent .= "<p>Review status updated to $rc</p>";
		//Now update likes/dislikes for the host
		$revdata = read_review($rid);
		//Send email to the user
		$mailid = $revdata['email'];
		$hid = $revdata['website_id'];
		$hostreviewslink = $siteurl . "index.php?a=showReviews&h=" . $hid;
		
		$sub = "Your review submitted at " . $sitename;
		if($rc == "true")
		{
			$msgtxt = <<<TXT

Your review comment can be seen at this URL:

$hostreviewslink

TXT;
		}
		
		$msg = <<<TXT

This email is to confirm that your review submitted at $sitename has been reviewed by the site admin.

Your review is approved? - $rc (true = approved and false = rejected)

Comment from site admin - $rcomm

$msgtxt

Thank you,
Site Admin
$siteurl

TXT;

 		if(send_mail_plain($mailid,$noreply_email,$sub,$msg))
		{
			$pagecontent .= "<p>Email sent to $mailid </p>";
		}
		else
		{
			$pagecontent .= "<p>Error sending email. ";
		}

		if(sizeof($revdata)>0 and $rc == "true")
		{
			
			
			$hlorn = $revdata['likeornot'];
			if($hid>0)
			{
				if($hlorn == "Y")
				{
					$q1="UPDATE website SET totallikes = totallikes + 1 WHERE id = $hid";				
				}
				else
				{
  				$q1="UPDATE website SET totaldislikes = totaldislikes + 1 WHERE id = $hid";
				}
				if($r1=mysql_query($q1))
				{
					$pagecontent .= "<p>Total likes/dislikes are updated</p>";
				}
				else
				{
					$pagecontent .= "<p>Error while updating likes/dislikes.</p>" . mysql_error();
				}
			}
		}
	}
	else
	{
		$pagecontent .= "<p>Error updating the review.</p>" . mysql_error();
	}	
}

function read_review($revid)
{
	$q="SELECT * FROM website_review WHERE id = $revid";
	if($r=mysql_query($q))
	{
		return mysql_fetch_array($r);
	}
}


//Approve reviews
function approveHost($hoid)
{
	global $pagecontent;
	if($hoid > 0)
	{
		$q="SELECT * FROM website WHERE id = $hoid";
	}
	else
	{
		$q="SELECT * FROM website ORDER BY id DESC";
	}
	if($r=mysql_query($q))
	{		
		while($rdata=mysql_fetch_array($r))
		{
			if($hoid)
			{
				$pagecontent .= "<hr>";
				foreach($rdata as $key=>$value)
				{
					if(is_numeric($key))
					{
					}
					else
					{
	 	 				if($key == "id")
	  				{
	  					$hid = $value;
	  				}
						if($key == "website_link")
						{
							$value = "<a href='$value' target='_blank'>$value</a>";
						}
	  				$pagecontent .= <<<HTM
	  					<p>$key - $value 
HTM;

					}
				}
				$pagecontent .= <<<HTM
  				
	  				<form action="admin.php?a=approveHost1" method="post">
 		 					<p>Select review outcome - <select name="outcome">
  						<option value="true">Approve</option>
  						<option value="false">Reject</option>
  						</select>
  						</p>
  						<p>Comment - <input type="text" name="comment" size="50" maxlength="200"></p>
  						<input type="hidden" name="hid" value="$hid">
  						<p><input type="submit" value="Submit"></p>
  					</form>
HTM;
			}
			else
			{
				$sitehostid = $rdata['id'];
				$sitehoststatus = $rdata['status'];
				if($sitehoststatus == "")
				{
					$sitehoststatus = "N";
				}
				$sitehoststatuscomment = $rdata['reviewcomment'];
				
				$pagecontent.= <<<HTM
					<hr>Host ID -> <a href="admin.php?a=approveHost&hid=$sitehostid">$sitehostid</a> - Status -> $sitehoststatus - Comment -> $sitehoststatuscomment
HTM;
			}
		}
	}
}

function approveHost1($hid, $rc, $rcomm)
{
	global $pagecontent;
	$pagecontent .= "<p>Host ID - $hid -> Result - $rc</p>";
	if($rc == 'true')
	{
		$rcc = 'Y';
	}
	else
	{
		$rcc = 'N';
	}
	$q="UPDATE website SET status = '$rcc', reviewcomment = '$rcomm' WHERE id = $hid";
	if($r=mysql_query($q))
	{
		$pagecontent .= "<p>Status updated to $hid</p>";
	}
	else
	{
		$pagecontent .= "<p>Error updating the host.</p>" . mysql_error();
	}	
}

//Adjust the host on a review
function adjustHost($rid, $newhost)
{
	global $pagecontent;
	$pagecontent .= "Adjusting host for review id - $rid to $newhost";
	if($newhost == "-1")
	{
		$pagecontent .= get_message_code(0, "Select the new host.");
		return;
	}
	
	$q="UPDATE website_review SET website_id = $newhost WHERE id = $rid";
	if($r=mysql_query($q))
	{
		$pagecontent .= get_message_code(1, "Update successful.");
	}
	else
	{
		$pagecontent .= get_message_code(0, mysql_error());
	}
}
?>