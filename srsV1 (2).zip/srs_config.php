<?php
//This file is the main config file. Update the variables in this folder.
//Without updating this file properly, the application will not work.
//Read the details given next to each variable to understand their purpose.

$dbhost = "";   //Host of the DataBase
$dbname = "";   //DB Name
$dbuser = "";   //DB user name
$dbpwd = "";    //DB user password

$sitename = ""; //Name of the site
$admin_email = ""; //Admin email
$noreply_email = ""; //Noreply email
$siteurl = ""; //Base URL
$entriesperpage = 15; //Number of entries per page (Sites that will be reviewed)
$reventriesperpage = 10; //Number of entries per page (reviews)

$templateNumber = "1"; //Number of the template you want to use for your site
?>