<?
include_once("srs_config.php");
include_once("srs_funs.php");
global $pagecontent, $metatitle, $metadesc, $templateNumber;

$link = dbconnect();
$act=$HTTP_GET_VARS['a'];

switch($act)
{
	case "";
		$startfrom = $HTTP_GET_VARS['s'];
		showDir($startfrom);
		break;
	case "showSubmitReviewForm";
		$hid = $HTTP_GET_VARS['h'];
		if($hid == "")
		{
			$hid = -1;
		}
		showSubmitReviewForm($hid);
		break;
	case "submitreview";
		$hoid = $HTTP_POST_VARS['hid'];
		$hona = $HTTP_POST_VARS['hn'];
		$hour = $HTTP_POST_VARS['hu'];
		$liyn = $HTTP_POST_VARS['likeornot'];
		$revt = $HTTP_POST_VARS['reviewtext'];
		$revw = $HTTP_POST_VARS['revweb'];
		$revn = $HTTP_POST_VARS['revname'];
		$reve = $HTTP_POST_VARS['reveml'];
		
		submitreview($hoid, $hona, $hour, $liyn, $revt, $revw, $revn, $reve);
		
		break;
	case "confirmreview";
		$hn = $HTTP_POST_VARS['hostn'];
		$hu = $HTTP_POST_VARS['hourl'];
		$lf = $HTTP_POST_VARS['lino'];
		$rt = $HTTP_POST_VARS['revi'];
		$rw = $HTTP_POST_VARS['rweb'];
		$rn = $HTTP_POST_VARS['rwen'];
		$reml = $HTTP_POST_VARS['rwee'];
		
		confirmreview($hn, $hu, $lf, $rt, $rw, $rn, $reml);		
		break;
	case "showReviews";
		$hid = $HTTP_GET_VARS['h'];
		$startfrom = $HTTP_GET_VARS['s'];
		showReviews($hid, $startfrom);
		break;
	case "addHost";
		addHost();
		break;
	case "discounthosting";
		discounthosting();
		break;
}

//Read stats
$q="SELECT COUNT( * ) FROM website WHERE status = 'Y'";
if($r=mysql_query($q))
{
	$hdata=mysql_fetch_array($r);
	$totalhosts = $hdata[0];
}
$q="SELECT COUNT( * ) FROM website_review WHERE status = 'Y'";
if($r=mysql_query($q))
{
	$hdata=mysql_fetch_array($r);
	$totalreviews = $hdata[0];
}

$statscode = <<<HTM
<i>Total sites listed: <a href="index.php"><b>$totalhosts</b></a> :: Total reviews submitted: <a href="index.php?a=showReviews"><b>$totalreviews</b></a></i>
HTM;

$sn = $_SERVER['SERVER_NAME'];
$sn .= $_SERVER['PHP_SELF'];
$textlinkscode = file_get_contents('http://www.monitor-line.com/text_links.php?r='.$sn);

////Read the template
//$userdomain = $_SERVER['HTTP_HOST'];
$templateFile = "templates/$templateNumber/template.html";

$templateCode = file_get_contents('$templateFile');

//Replace placeholders
$templateCode = str_replace("[PAGELINKS]", $textlinkscode, $templateCode);
$templateCode = str_replace("[PAGECONTENT]", $pagecontent, $templateCode);
$templateCode = str_replace("[STATS]", $statscode, $templateCode);
$templateCode = str_replace("[METADESC]", $metadesc, $templateCode);
$templateCode = str_replace("[METATITLE]", $metatitle, $templateCode);
$templateCode = str_replace("[TEXTLINKS]", $textlinkscode, $templateCode);

//Show the page
echo $templateCode;

dbclose($link);
?>
