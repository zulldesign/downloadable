-- phpMyAdmin SQL Dump
-- version 3.4.3.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 14, 2011 at 08:04 AM
-- Server version: 5.0.92
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `expertho_dball`
--

-- --------------------------------------------------------

--
-- Table structure for table `website`
--

DROP TABLE IF EXISTS `website`;
CREATE TABLE IF NOT EXISTS `website` (
  `id` int(11) NOT NULL auto_increment,
  `website_name` varchar(100) default NULL,
  `website_link` text,
  `company` varchar(100) default NULL,
  `feature_text` varchar(250) NOT NULL,
  `bonus_feature_text` varchar(250) NOT NULL,
  `coupon_code` varchar(15) NOT NULL,
  `hotline` varchar(100) NOT NULL,
  `coupon_desc` varchar(250) NOT NULL,
  `status` enum('Y','N') default 'N',
  `is_deleted` enum('Y','N') default 'N',
  `totallikes` int(11) NOT NULL default '0',
  `totaldislikes` int(11) NOT NULL default '0',
  `reviewcomment` text NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `website_name` (`website_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=184 ;

-- --------------------------------------------------------

--
-- Table structure for table `website_rating`
--

DROP TABLE IF EXISTS `website_rating`;
CREATE TABLE IF NOT EXISTS `website_rating` (
  `id` int(11) NOT NULL auto_increment,
  `website_id` int(11) default NULL,
  `rating_points` tinyint(4) default NULL,
  `visitor_count` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

-- --------------------------------------------------------

--
-- Table structure for table `website_review`
--

DROP TABLE IF EXISTS `website_review`;
CREATE TABLE IF NOT EXISTS `website_review` (
  `id` int(11) NOT NULL auto_increment,
  `reviewtime` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `website_id` int(11) default NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `review_text` text,
  `rating_points` tinyint(4) NOT NULL,
  `likeornot` varchar(1) NOT NULL,
  `visitor_id` int(11) default NULL,
  `status` enum('Y','N') NOT NULL default 'N',
  `ip` varchar(20) NOT NULL,
  `reviewer_site` varchar(200) NOT NULL,
  `reviewersiteok` varchar(1) NOT NULL default 'N',
  `reviewcomment` varchar(200) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=237 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
