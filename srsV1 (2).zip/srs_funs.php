<?php
//Functions included in this file
//function to establish a connection to MySQL and selecting a database to work
function dbconnect()
{
	global $siteadds,$dbhost,$dbname, $dbuser, $dbpwd;
	if($link = mysql_connect($dbhost, $dbuser, $dbpwd))
	{
		$res=mysql_select_db($dbname) or die(mysql_error());
		if($res)
			return $link;
	}
	else
		print "There is some internal error in retrieving the records. Sorry for the inconvinence.";
}
//function  to close the opened link
function dbclose($link)
{
	global $link;
	if(mysql_close($link))
	{}
}
//Show submit review form
function showSubmitReviewForm($hostid)
{
	global $metatitle, $pagecontent, $sitename, $metadesc;
	if($hostid != "")
	{
		$hostdata = read_host_details($hostid, "");
		$hostname = $hostdata['website_name'];
	}
	if($hostname != "")
	{
		$hosturl = $hostdata['website_link'];
		$inputflag = "disabled";
		
		$metatitle = "Submit reviews about $hostname at $sitename";
		$metadesc = "Submit review about $hostname and get life-long, one-way text link from $sitename. Also get free banner ads, quality traffic, hosting credits and more.";
	}
	else
	{
		$metatitle = "Submit review about hosting company at $sitename and get free PHP scripts";
		$metadesc = "Submit review about your hosting company and get free PHP scripts for tell-a-friend and PHP PayPal store creator. Also get free banner ads, quality traffic, hosting credits and more.";
	}
	
	//Why should someone submit a review?
	$incentivestext = <<<HTM
		<p>You should submit your review because:</p>
		<ol>
			<li>You will be helping your fellow webmasters make an informed decision about which host to choose.</li>
			<li>You will get free PHP scripts - Tell-a-friend and PayPal Store Creator instantly after you submit your review.</li>
		</ol>
HTM;
	//Show the form
	$pagecontent .= <<<HTM
		<p><b>$metatitle</b></p>
		<p>$metadesc</p>
		<table border="1" cellpadding="5" cellspacing="0" summary="" align="center" width="80%">
			<tr>
				<td>
					<p><b>Why should you submit a review?</b></p>
					$incentivestext
				</td>
			</tr>
		</table>
		<p><b>Use the form below to submit review</b></p>
		<form action="index.php?a=submitreview" method="post">
			<p><u>About the hosting company:</u></p>
			<input type="hidden" name="hid" value="$hostid">
			<p>Name of hosting company: <input type="text" name="hn" value="$hostname" size="25" maxlength="100" $inputflag></p>
			<p>Hosting company URL: <input type="text" name="hu" value="$hosturl" size="50" maxlength="250" $inputflag></p>
			<p><u>Your review comment and rating:</u></p>
			<p>Do you like this hosting company (would you recommend it to other webmasters?)? - <select name="likeornot" >
				<option selected="yes" value="Y">YES</option>
				<option value="N">NO</option>
			</select>
			</p>
			<p>Enter your review comment:</p>
			<textarea name="reviewtext" cols="50" rows="10"></textarea>
			<p>Enter your website URL: (This must be the website hosted at this host) <input type="text" name="revweb" size="50" maxlength="200"></p>
			<p>Enter your name: (This will be shown next to your review comment) <input type="text" name="revname" size="25" maxlength="100"></p>
			<p>Enter your email address: (We will let you know at this address once your review is approved) <input type="text" name="reveml" size="50" maxlength="100"></p>
			<p><input type="submit" value="Submit review"></p>
		</form>
HTM;
}

//Read details about the hosting company
function read_host_details($hostid, $hostname)
{
	if($hostid)
	{
		$q="SELECT * FROM website WHERE id = $hostid";
	}
	
	if($hostname)
	{
		$q="SELECT * FROM website WHERE website_name = '$hostname'";
	}
	if($r=mysql_query($q))
	{
		$hostdata = mysql_fetch_array($r);
	}
	if(sizeof($hostdata)>0)
	{
		//Do nothing
	}
	else
	{
		$hostdata['website_name'] = "";
	}
	
	return $hostdata;
}

//Submit review form - firs submission
function submitreview($hoid, $hona, $hour, $liyn, $revt, $revw, $revn, $reve)
{
	global $metatitle, $pagecontent, $sitename, $metadesc;
	$metatitle = "Confirm review comment";
	$metadesc = "";
	
	//Check if the hosting ID is for a valid record
	if($hoid != "" and $hoid != -1)
	{
		$hostdata = read_host_details($hoid, "");
		$hona = $hostdata['website_name'];
		$hour = $hostdata['website_link'];
	}
	
	//All fields are mandatory
	if($hona == "" or $hour == "" or $liyn == "" or $revt == "" or $revw == "" or $revn == "" or $reve == "")
	{
		$pagecontent .= get_message_code(0, "All fields are mandatory. Try again.");
		$metatitle = "ERROR!"; return;
	}
	
	//Check all URLs
	if(!isValidURL($revw))
	{
		$pagecontent .= get_message_code(0, "Your website URL is incorrect. Try again. You entered '$revw'");
		$metatitle = "ERROR!"; return;
	}
	if(!isValidURL($hour))
	{
		$pagecontent .= get_message_code(0, "Host URL is incorrect. Try again. You entered '$hour'. ");
		$metatitle = "ERROR!"; return;
	}
	
	//Is email valid?
	if(isValidEmail($reve) == false)
	{
		$pagecontent .= get_message_code(0, "Invalid email entered. Please try again. Note that we do not misuse emails. We have strong privacy policy. Email is used to contact you regarding your review comments. Please try again. ");
		$metatitle = "ERROR!"; return;
	}
	
	//Remove HTML Tags from host name and review comment
	$hona = strip_tags($hona);
	$revt = strip_tags($revt);
	$revn = strip_tags($revn);
	
	//Remove all unwated characters from the review comment
	
	$revt = ereg_replace("[^A-Za-z0-9. ]", "", $revt); 
	$revn = ereg_replace("[^A-Za-z0-9. ]", "", $revn);
	
	$pagecontent .= <<<HTM
		<p><font size="4"><b>Confirm your submission</b></font></p>
		<p><u>Please confirm your submission:</u></p>
		<p>Host name - <font color="#0000cc">$hona</font></p>
		<p>Host URL - <font color="#0000cc">$hour</font> (<a href="$hour" target="_blank">Visit the host's site</a> to make sure the URL is correct.)</p>
		<p>Do you like this host? <font color="#0000cc">$liyn</font></p>
		<p>Your review comments: (note all non-alphanumeric characters are removed for security reasons.)</p>
		<p><font color="#0033cc">$revt</font></p>
		<p>Your website URL - <font color="#0000cc">$revw</font> (<a href="$revw" target="_blank">Visit your website</a> to make sure the link is correct.)</p>
		<p>Your name - <font color="#0000cc">$revn</font></p>
		<p>Your email - <font color="#0000cc">$reve</font> </p>
		<form action="index.php?a=confirmreview" method="post">
			<input type="hidden" name="hostn" value="$hona">
			<input type="hidden" name="hourl" value="$hour">
			<input type="hidden" name="lino" value="$liyn">
			<input type="hidden" name="revi" value="$revt">
			<input type="hidden" name="rweb" value="$revw">
			<input type="hidden" name="rwen" value="$revn">
			<input type="hidden" name="rwee" value="$reve">
			
			<p><input type="submit" value="Confirm submission"></p>
		</form>
HTM;
}

//Show message (0 = Error, 1 = Success, 2 = Information)
function get_message_code($msgtyp, $msgtxt)
{
	if($msgtyp == 0)
	{
		$msgcode = "<p><b><font color='#ff0000'>Error!</b> " . $msgtxt . "</font></p>";
	}
	
	if($msgtyp == 1)
	{
		$msgcode = "<p><b><font color='#006633'>Success!</b> " . $msgtxt . "</font></p>";
	}
	
	if($msgtyp == 2)
	{
		$msgcode = "<p><b><font color='#000000'>Success!</b> " . $msgtxt . "</font></p>";
	}
		
	return $msgcode;
}

//Check if the URL is valid
function isValidURL($ur)
{
	if (preg_match('|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i', $ur)) 
	{
		return true;
	}
	else
	{
		return false;
	}
}

//Confirm the review submission
function confirmreview($hn, $hu, $lf, $rt, $rw, $rn, $reml)
{
	global $pagecontent, $admin_email, $noreply_email, $metatitle, $metadesc, $sitename, $siteurl;
	$showScriptsDownloadLink = 0;
	//First try to add the host
	$q="INSERT INTO website SET website_name = '$hn', website_link = '$hu', company = '$hn'";
	if($r=mysql_query($q))
	{
		$pagecontent .= get_message_code(1, "Host '$hn' added to the database.");
		$hostid = mysql_insert_id();
	}
	else
	{
		$hostdata = read_host_details(0, $hn);
		$hostid = $hostdata['id'];
		if($hostid)
		{
			$pagecontent .= get_message_code(2, "Host '$hn' already exists. New record was not created.");
		}
		else
		{
			$pagecontent .= get_message_code(0, "Data issue. Cannot proceed. Contact siet admin.");
			$metatitle = "ERROR!";
			return;
		}		
	}
	//IP address
	$ip = $_SERVER['REMOTE_ADDR'];
		
	//Check if this IP and host id already exist
	$q="SELECT * FROM website_review WHERE website_id = $hostid AND ip = '$ip'";
	if($r=mysql_query($q))
	{
		if(mysql_num_rows($r) > 0)
		{
			$pagecontent .= get_message_code(0, "You have already reviewed this host. Cannot submit multiple reviews for the same host.");
			$metatitle = "ERROR!";
			return;
		}
	}
	//Now insert the review comment
	$q="INSERT INTO website_review SET name = '$rn', email = '$reml', website_id = $hostid, review_text = '$rt', likeornot = '$lf', ip = '$ip', reviewer_site = '$rw'";
	if($r=mysql_query($q))
	{
		$pagecontent .= get_message_code(1, "Your review comment added successfully. Thank you!");
		$metatitle = "SUCCESS!";
		$revid = mysql_insert_id();
	}
	else
	{
		$pagecontent .= get_message_code(0, "Review comment could not be added. Contact admin with following details: " . mysql_error());
		$metatitle = "ERROR!";
		return;
	}
	
	//Now send email to the site admin
	
	$msgsub = "New review at $sitename - " . time();
	$msgtxt = <<<TXT

New review at $sitename

$siteurl/admin/admin.php?a=approveHost&hid=$hostid

$siteurl/admin/admin.php?a=approveReview&revid=$revid


TXT;

	if(send_mail_plain($admin_email,$noreply_email,$msgsub,$msgtxt))
	{
		$pagecontent .= get_message_code(1, "Email sent to site admin successfully. Please wait for site admin to review your submission.");
		$showScriptsDownloadLink = 1;
	}
	else
	{
		$pagecontent .= get_message_code(0, "Email could not be sent. Contact site admin.");
	}
	
	//Show the scripts download link if everything was ok
	if($showScriptsDownloadLink == 1)
	{
		$pagecontent .= <<<HTM
			<table border="1" cellpadding="5" cellspacing="0" summary="" align="center" width="80%">
  			<tr>
  				<td>
  					<p><b>Here are your promised bonuses!</b></p>
      			<p>1 - Here are some free scripts for you as a special thank you! <a href="http://monitor-line.com/listthankyou.php">Download free scripts here ...</a></p>
						<p>2 - Professional banner or logo for your website! <a href="http://www.webbannersandlogos.com" target="_blank">WebBannersAndLogos.com</a></p>
  				</td>
  			</tr>
  		</table>

HTM;
	}
}

//Send plain email
function send_mail_plain($mailid,$fromid,$sub,$msg)
{
	global $def_eml_ad, $emailadcode;
	//print "$mailid,$fromid,$sub,$msg";
  $headers  = "MIME-Version: 1.0\r\n";
  $headers .= "Content-type: text/plain; charset=iso-8859-1\r\n";
  /* additional headers */
  $headers .= "From: $fromid\r\n";
  $headers .= "Reply-To: $fromid\r\n";
	$msg="$msg".$def_eml_ad;
	//this will send mail to each person individually.
	$mailid=split(",",$mailid);
  for($i=0;$i<count($mailid);$i++)
  {
  	//echo"Message : $msg";
		$msg = $emailadcode . $msg;

    if(mail($mailid[$i], $sub, $msg,$headers))
  	{
  	}
  	else
  	{
  		print "<br>Error sending email to $mailid[$i]";
  		exit;
  	}
 	}
  return 1;
}

//Is email valid?
function isValidEmail($email)
{
	return eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $email);
}

//Show the host rankings
function showDir($st)
{
	global $metatitle, $metadesc, $pagecontent, $sitename, $entriesperpage;
	$metatitle = $sitename . " top hosting companies are reviewed by real webmasters and ranked by popularity";
	$metadesc = "One of the most unbiased and true rankings of hosting companies where real webmasters have reviewed the hosting providers where their sites are hosted. No biased and sponsored hosting reviews like other ranking sites.";
	//Select the hosts in an array
	$q="SELECT * FROM website WHERE status = true";
	if($r=mysql_query($q))
	{
		while($hdata=mysql_fetch_array($r))
		{
			$hid = $hdata['id'];
			$hn = $hdata['website_name'];
			$hlikes = $hdata['totallikes'];
			$hdislikes = $hdata['totaldislikes'];
			$hlink = $hdata['website_link'];
			
			$harraylikes[$hn] = $hlikes;
			$harraydislikes[$hn] = $hdislikes;
			$harraylinks[$hn] = $hlink;
			$harrayids[$hn] = $hid;
			
			$hscore = $hlikes - $hdislikes;
			$harray[$hn] = $hscore;
		}
		
		//Sort the array
		arsort($harray);
		$pagecontent .= <<<HTM
		<table class="tableborder" width="100%" cellspacing="2" cellpadding="0" border="0">
			<tbody>
				<tr>
					<td valign="top" align="left">
						<table width="100%" cellspacing="0" cellpadding="0" border="0">
							<tbody>
								<tr>
									<td class="td_right_border" height="25" valign="middle" bgcolor="#e03434" align="center">
										<span class="table_headings">Rank</span>
									</td>
									<td class="td_right_border" height="25" valign="middle" bgcolor="#e03434" align="center">
										<span class="table_headings">Web Hosting Provider</span>
									</td>
									<td class="td_right_border" height="25" valign="middle" bgcolor="#e03434" align="center">
										<span class="table_headings"><img src="images/like.jpg" width="22"> Likes</span>
									</td>
									<td class="td_right_border" height="25" valign="middle" bgcolor="#e03434" align="center">
										<span class="table_headings"><img src="images/dislike.jpg" width="22"> Dislikes</span>
									</td>

									<td class="table_headings" height="25" valign="middle" bgcolor="#e03434" align="center">
										Actions									</td>
								</tr>
								
HTM;
		foreach($harray as $key=>$value)
		{
			$i = $i + 1;
			if($i>$st and $i<=($st + $entriesperpage))
			{
				$pagecontent .= <<<HTM
				
					<tr bgcolor="#f0f1f2">
        					<td class="td_right_bottom_border" valign="middle" align="center" height="50">
        						<span class="pinknumbs">$i</span></td>
          					<td class="td_right_bottom_border" valign="middle" align="left">
          						<div>
          						<a class="bodylinks" target="_top" href="index.php?a=showReviews&h=$harrayids[$key]">$key</a>
  							</div>
  						</td>
						<td class="td_right_bottom_border" valign="middle" align="center">
         				 		<span class="likes">$harraylikes[$key]</span>
          					</td>
						<td class="td_right_bottom_border" valign="middle" align="center">
         				 		<span class="dislikes">$harraydislikes[$key]</span>
          					</td>
          					<td class="td_right_bottom_border" valign="middle" align="center">
          						<div class="slogantxt"><a class="body_text_link" href="index.php?a=showReviews&h=$harrayids[$key]">View Reviews</a></div>
          						<div class="slogantxt"><a class="body_text_link" href="index.php?a=showSubmitReviewForm&h=$harrayids[$key]">Review it</a></div>
          					</td>
        				</tr>
				
HTM;
			}
		}
		
		$pagecontent .= "</tbody></table></td></tr></tbody></table>";
		
		//Decide the paging variables
		$prev = $st - $entriesperpage;
		if($prev < 0)
		{
			$prev = 1;
		}
		
		$nxt = $st + $entriesperpage;
		if($nxt > $i)
		{
			$nxt = 1;
		}
		
		if($prev != 1)
		{
			$prevcode = "<a href='index.php?a=&s=$prev'>Previous</a>";
		}
		if($nxt != 1)
		{
			$nxtcode = "<a href='index.php?a=&s=$nxt'>Next</a>";
		}
		
		$pagecontent .= <<<HTM
			<table border="0">
				<tr>
					<td align="left" width="50%">$prevcode</td>
					<td align="right" width="50%">$nxtcode</td>
				</tr>
			</table>
HTM;
		
	}
}

//Show the host rankings
function showReviews($hid, $st)
{
	global $metatitle, $metadesc, $pagecontent, $sitename, $reventriesperpage;
	if($hid == "")
	{
		$metatitle = "Reviews submitted by real webmasters about hosting companies";
		$metadesc = "Our hosting directory is made up of listings of hosting companies and reviews submitted by real webmasters about those hosting companies. See the reviews in the descending order of their entry time.";
	}
	else
	{
		$hostdata = read_host_details($hid, "");
		$hostname = $hostdata['website_name'];
		$hostlink = $hostdata['website_link'];
		$metatitle = "Real, unbiased reviews submitted about $hostname by real webmasters";
		$metadesc = "Our hosting directory has real, unbiased and unsponsored reviews submitted by real webmasters about $hostname hosting company.";
	}
	//Show the host details at the top of the page
	if($hostname)
	{
		$pagecontent .= <<<HTM
			<table class="tableborder" width="100%" cellspacing="2" cellpadding="0" border="0">
				<tbody>
					<tr>
						<td valign="top" align="left"class="arialred18">
							Reviews submitted for <i><a href="$hostlink" target="_blank">$hostname</a></i>
						</td>
					</tr>
				</tbody>
			</table>
			<p>Note that reviews are shown in the decending order of the time they were submitted (latest review on top).</p>
HTM;
	}
	else
	{
		$pagecontent .= <<<HTM
			<table class="tableborder" width="100%" cellspacing="2" cellpadding="0" border="0">
				<tbody>
					<tr>
						<td valign="top" align="left"class="arialred18">
							Reviews submitted for hosts listed in our directory.
						</td>
					</tr>
				</tbody>
			</table>
			<p>Note that reviews are shown in the decending order of the time they were submitted (latest review on top).</p>
HTM;

	}
	//Build the select query
	if($hostname)
	{
		$q="SELECT * FROM website_review WHERE website_id = $hid AND status = 'Y' ORDER BY id DESC";
	}
	else
	{
		$q="SELECT * FROM website_review WHERE status = 'Y' ORDER BY reviewtime DESC";
	}
	if($r=mysql_query($q))
	{
		while($rdata=mysql_fetch_array($r))
		{
			$i = $i + 1;
			if($i>$st and $i<=($st + $reventriesperpage))
			{
  			$rid = $rdata['id'];
  			
  			if($hostname == "")
  			{
  				$hostid = $rdata['website_id'];
  				$hostdata = read_host_details($hostid, "");
      		$hostname1 = $hostdata['website_name'];
      		$hostlink = $hostdata['website_link'];
  				$hcode = <<<HTM
  					<i><a href="$hostlink" target="_blank">Visit $hostname1</a></i>
HTM;
  			}
  			$rname = $rdata['name'];
  			$rtime = $rdata['reviewtime'];
  			$rweb = $rdata['reviewer_site'];
  			$rflag = $rdata['likeornot'];
  			$rtext = $rdata['review_text'];
  			$rsflag = $rdata['reviewersiteok'];
  			//Build reviewer site link
  			if($rsflag == 'Y')
  			{
  				$rweb = <<<HTM
  					<a href="$rweb" target="_blank">$rweb</a>
HTM;
  			}
  			
  
  			//Show the flag color
  			if($rflag == 'Y')
  			{
  				$rflag = <<<HTM
  					<img src="images/like.jpg" alt="like" width="25"><font color="#006600"><b>$rflag</b></font>
HTM;
  
  			}
  			else
  			{
  				$rflag = <<<HTM
  					<img src="images/dislike.jpg" alt="like" width="25"><font color="#FF3300"><b>$rflag</b></font>
HTM;
  
  			}
  
  			
  			$pagecontent .= <<<HTM
  				<p><b>Review ID <i>$rid</i>: Submitted by <i>$rname</i> on <i>$rtime</i></b> $hcode <br>
  				<u>Reviewer's website: </u> $rweb</p>
  				<table class="tableborder" width="100%" cellspacing="2" cellpadding="0" border="0">
  					<tbody>
  						<tr>
  							<td class="td_right_bottom_border" valign="top" align="left" width="150">
  								Recommended (Y/N)?
  							</td>
  							<td class="td_right_bottom_border" valign="top" align="center">
  								$rflag
  							</td>
  						</tr>
  						<tr>
  							<td class="td_right_bottom_border" valign="top" align="left" width="150">
  								Review comment
  							</td>
  							<td class="td_right_bottom_border" valign="top" align="left">
  								$rtext
  							</td>
  						</tr>
  					</tbody>
  				</table>
HTM;
  
  
  		}
		}
		//Decide the paging variables
		$prev = $st - $reventriesperpage;
		if($prev < 0)
		{
			$prev = 1;
		}
		
		$nxt = $st + $reventriesperpage;
		if($nxt > $i)
		{
			$nxt = 1;
		}
		
		if($prev != 1)
		{
			$prevcode = "<a href='index.php?a=showReviews&h=$hid&s=$prev'>Previous</a>";
		}
		if($nxt != 1)
		{
			$nxtcode = "<a href='index.php?a=showReviews&h=$hid&s=$nxt'>Next</a>";
		}
		
		$pagecontent .= <<<HTM
			<table border="0">
				<tr>
					<td align="left" width="50%">$prevcode</td>
					<td align="right" width="50%">$nxtcode</td>
				</tr>
			</table>
HTM;

		//If there are no reviews then show the message
		if($i == 0)
		{
			$pagecontent .= <<<HTM
				<p><b>There no reviews found. Be the first one to submit reviews about <u>$hostname</u></b></p>
HTM;
		}
	}
}

//Show the host rankings
function addHost()
{
	global $metatitle, $metadesc, $pagecontent;
	$metatitle = "Add a host to our directory";
	$metadesc = "Add host to our directory. Use the submit form and add a new hosting company to our hosting review directory.";
	$pagecontent .= <<<HTM
		<p><font size="4"><b>Add a host</b></font></p>
		<p>If you want to add a new host to our directory, use the 'Submit Review' form and add the hosting company details in the top section. Fill the rest of the sections with dummy data. Once your form is submitted and reviewed by the site admin, your new entry will be added to the site.</p>
HTM;

}

//Discount hosting offers
function discounthosting()
{
	global $metatitle, $pagecontent, $sitename, $metadesc;
	$metatitle = "Hosting discounts and cashback offers";
	$metadesc = "Special offers from top hosting providers with discounts and cashbacks. Coupons and immediate discounts are listed.";
	$pagecontent .= <<<HTM
		<p><b>$metatitle</b></p>
		<p>$metadesc</p>
		<div align="center">
  <center>
  <table border="0" cellpadding="5" cellspacing="0" bgcolor="#B5DBD3" width="550">
    <tr>
      <td>
			<p align="center"><span style="background-color: #FFFF00">Offer # 1 brought to
you by founder and creator of ExpertHostingReview and ProfitSharingHost.com</span></p>
<p align="center"><font color="#000258" face="Arial Black" size="5">One .com,
.net, .biz&nbsp;or .info domain name of your choice starting at&nbsp;7 Cents
PLUS Amazing bonuses!</font></p>
<p align="center"><font color="#003162" face="Arial Black" size="4"><strong>Select
any domain you like and I will register it for you
under your name.</strong></font></p>
<p align="center">&nbsp;</p>
<p align="center"><font face="Arial" size="2"><strong><font size="3">Why am I
giving away domain names so cheap?</font></strong></font></p>
<p align="center"><font face="Arial" size="2">I am doing this&nbsp;in order to
promote my hosting and domain site - <a href="http://www.profitsharinghost.com/" target="_blank">ProfitSharingHost.com</a></font></p>
<p>&nbsp;</p>
<p align="center"><font size="3" face="Arial"><strong>Where will I get the
domain from?</strong></font></p>
<p align="center"><font face="Arial" size="2">I am reseller for one of the top
domain and hosting resellers today - <a href="http://www.resellerspanel.com/a/schopade" target="_blank">ResellersPanel.com</a>
. I will get the domain from them. ResellersPanel is one of the top domain and
hosting resellers today. In other words - you and your domain will be in safe
hands. Evenif I close the shop tomorrow, you will still be supported by this
domain and hosting reseller giant. They are behind hundreds of domain registrars
and hosts today. You can become a reseller too and follow my techniques to
generate your own paying customers!</font></p>
<p align="center">&nbsp;</p>
<p align="center"><font face="Arial" size="2"><strong><font size="3">How will
this work?</font></strong></font></p>
<p align="center"><font face="Arial" size="2">Use the link at the bottom of this
page and go to my eBay Auctions. You will find one of the auctions for the domain
name. You pay the winning bid. Make sure the domain you are looking for is not
already registered. Send an email to me with the domain name. I will acquire the
domain name at regular price for&nbsp;you via my domain and hosting site - <a href="http://www.profitsharinghost.com/" target="_blank">ProfitSharingHost.com</a>.
I will create your domain management control panel account at my site. I will
hand over the domain control panel login details&nbsp;to you once everything is
setup. You can check to make sure the contact details etc is all setup
correctly. Make sure you change the password to the control panel to secure your
domain and avoid further unauthorized access. Once all is done, enjoy the
domain!</font></p>
<p align="center"><font face="Arial" size="2"><strong><font size="3">What is the
catch?</font></strong></font></p>
<p align="center"><font face="Arial" size="2">There is no catch. I am a 100%
feedback seller on eBay for many years now. You can rest assured, there is no
trick or catch in this. I am doing this because after many years of struggle
online, I found out that programs like <a href="http://www.resellerspanel.com/a/schopade" target="_blank">ResellersPanel.com</a>
are the real money-makers on the Internet. Everything else is a waste of time. I
am giving you almost free domains so that you can come and try the service. If
you like it, you will make me enough money down the line. So don't worry. Buy a
domain of your dreams. I will also not bind you in any sort of conditions or
contracts. You can choose to continue to use my service or choose to move the
domain to whatever registrar you want. There are no conditions or contracts. You
will be paying for the domain at regular price from second year onwards.</font></p>
<p><font color="#fb0034" face="Arial Black" size="4"><u>Warning!</u> Please
place your bid only if you are serious about buying a domain name. If I find out
that you placed a bid only to get a&nbsp;positive feedback&nbsp;or if you are
not really using the domain name, I will cancel your account and also report you
to eBay as a fake bidder! Be careful.</font></p>
<p><font color="#fb0034" face="Arial Black" size="4">This offer is only for my
new customers. Old customers cannot bid to get another domain at this price.</font></p>
<p align="center"><font color="#ad001f" face="Arial Black" size="4"><u><strong>-------------------------------</strong></u></font></p>
<p align="center"><font color="#408641" face="Arial Black" size="4"><u><strong>Bonus
#1: One-way text link for 1 full year on HIGH PR sites</strong></u></font></p>
<p align="left"><font color="#000000" face="Arial"><strong>I am not done yet!</strong>
As a bonus, I will give you one-way text link from my top 7 HIGH PR sites for
one full year! If you move your domain to another registrar, I will remove the
link before the year is over. This is my way of giving some incentive to my
customers to stay with me. Your link will be shown on the following domain names
for <strong><u>ONE FULL YEAR</u></strong> from the time your domain is
registered. This is a great SEO offer for new sites. You cannot get a better
boost. Note that this link will be provided only for the domain you register
with me.</font></p>
<p><font face="Verdana" size="2">Your plain text link will show on following
websites (great for SEO)</font></p>
<ul>
  <li><a href="http://www.monitor-line.com/" target="_blank"><font face="Verdana" size="2">Monitor-Line.com</font></a>
    - <font face="Arial" size="2">our main company site that also gives away
    free PHP scripts.</font></li>
  <li><a href="http://www.monitor-line.com/dqcpc" target="_blank"><font face="Verdana" size="2">Monitor-Line.com
    DQCPC Visitors Network</font></a> - <font face="Arial" size="2">our new and
    unique ad network site where advertisers, publishers all win!</font></li>
  <li><a href="http://www.experthostingreview.com/" target="_blank"><font face="Verdana" size="2">ExpertHostingReview.com</font></a>&nbsp;-
    <font face="Arial" size="2">our real, unbiased, genuine hosting reviews site
    where real webmasters review their hosts</font></li>
  <li><a href="http://www.howtocreatewebsite.info/" target="_blank"><font face="Verdana" size="2">HowToCreateWebsite.INFO</font></a>
    - <font face="Arial" size="1"><font size="2">our free ebook for beginners on
    how to create your own website step-by-step with screenshots</font>.</font></li>
  <li><a href="http://www.imgfriendlylist.com/" target="_blank"><font face="Verdana" size="2">IMGFriendlyList.com</font></a>
    - <font face="Arial" size="1"><font size="2">our site dedicated to foreign
    students seeking medical education in USA</font>.</font></li>
  <li><a href="http://www.designersbase.com/" target="_blank"><font face="Verdana" size="2">DesignersBase.com</font></a>
    - <font face="Arial" size="1"><font size="2">our site for fashion design,
    banners and logo designs and much more related to the world of fashion and
    design</font>.</font></li>
  <li><a href="http://www.thestoresclub.com/" target="_blank"><font face="Verdana" size="2">TheStoresClub.com</font></a>&nbsp;-
    <font face="Arial" size="2">our site where any one can create a free online
    store with simple web-based interface and PayPal account.</font></li>
  <li><a href="http://www.signupformoney.com/" target="_blank"><font face="Verdana" size="2">SignUpForMoney.com</font></a>&nbsp;-
    <font face="Arial" size="2">our site that is dedicated to money-making
    programs and home-based business information.</font>
    <p align="center"><font face="Verdana" size="2"><strong><font color="#00456d"><u><font color="#fb0034">Note:</font></u>
    Anchor&nbsp;text can have up to 40 characters max (no exceptions possible).</font></strong></font></p>
  </li>
</ul>
<font color="#00456d" size="2" face="Verdana">
<p align="center">&nbsp;</p>
<p align="center"><font color="#408641" face="Arial Black" size="4"><u><strong>Bonus
#2: Free eBook - How to Create a Website?</strong></u></font></p>
<p align="center"><font color="#000000" face="Arial">I have written a simple
step-by-step instructions with screenshots - eBook - How To Create&nbsp;a
Website. You can get it for free as an added bonus.</font></p>
<p align="center">&nbsp;</p>
<p align="center"><font color="#408641" face="Arial Black" size="4"><u><strong>Bonus
#3: Life-Long one-way text link from ExpertHostingReview.com</strong></u></font></p>
<p align="left"><font color="#000000" face="Arial">If you submit a review about
the hosting company where your domain is going to be hosted, I will give you
one-way, <u><strong>LIFE-LONG</strong></u> text link from
ExpertHostingReview.com. You can see some of the recent reviews and how the
website link is provided next to the review as sample here - <a href="http://experthostingreview.com/index.php?a=showReviews&amp;h=58" target="_blank">Sample
Review</a>. If this is little confusing for you, please feel free to contact me
and&nbsp;I will explain how this works. Note that this applies only to the
domain name you purchase under this auction.</font></p>
<font color="#000000" face="Arial">
<p align="center"><font color="#408641" face="Arial Black" size="4"><u><strong>Bonus
#4: Premier Ad Listing&nbsp;on my&nbsp;HIGH Alexa PR Directory for LIFE!</strong></u></font></p>
<p align="center"><font color="#000000" face="Arial">I also run a directory
where I generate what I call &quot;Double Qualified&quot; visitors for my
customers. This is a HIGH PR directory and your listing will not only give you
good visitors but also a one-way, high-pr text link for life. You can find my
directory and some of the recent listings here - <a href="http://www.monitor-line.com/dqcpc/?a=dqcpc" target="_blank">Monitor-Line
DQCPC Visitors Directory</a>. Again, this applies only to the domain you
purchase under this auction.</font></p>
</font></font>
<p align="center"><a href="http://shop.ebay.com/monitor-line/m.html?_nkw=&amp;_armrs=1&amp;_from=&amp;_ipg=&amp;_trksid=p4340.m570.l1533" target="_blank"><font color="#000000" face="Arial" size="4"><span style="background-color: #00FFFF">Click
here to go to my eBay auction for the 7 Cent domains and place your bid now!</span></font></a></p>

			
			</td>
    </tr>
  </table>
  </center>
</div>


HTM;
}

?>