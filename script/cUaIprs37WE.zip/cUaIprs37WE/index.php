<?php
// Let us imagine these two variables have been acquired by dynamic means
// Mine are static values but yours will be dynamically rendered, right? Yes...
$id = "438";
$code = "czkjlliu";
?>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>AS3_php_2_Var_into_flash</title>
<script language="javascript">AC_FL_RunContent = 0;</script>
<script src="AC_RunActiveContent.js" language="javascript"></script>
</head>
<body bgcolor="#333333">
<!--url's used in the movie-->
<!--text used in the movie-->
<!-- saved from url=(0013)about:internet -->
<script language="javascript">
	if (AC_FL_RunContent == 0) {
		alert("This page requires AC_RunActiveContent.js.");
	} else {
		AC_FL_RunContent(
			'codebase', 'http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0',
			'width', '400',
			'height', '150',
			'src', 'AS3_php_Var_into_flash',
			'FlashVars', 'itemID=<?php print "$id"; ?>&itemCode=<?php print "$code"; ?>',			
			'quality', 'high',
			'pluginspage', 'http://www.macromedia.com/go/getflashplayer',
			'align', 'middle',
			'play', 'true',
			'loop', 'true',
			'scale', 'showall',
			'wmode', 'window',
			'devicefont', 'false',
			'id', 'AS3_php_Var_into_flash',
			'bgcolor', '#ffffff',
			'name', 'AS3_php_2_Var_into_flash',
			'menu', 'true',
			'allowFullScreen', 'false',
			'allowScriptAccess','sameDomain',
			'movie', 'AS3_php_2_Var_into_flash',
			'salign', ''
			); //end AC code
	}
</script>
<noscript>
	<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0" width="400" height="150" id="AS3_php_Var_into_flash" align="middle">
	<param name="allowScriptAccess" value="sameDomain" />
	<param name="allowFullScreen" value="false" />
	<param name="movie" value="AS3_php_2_Var_into_flash.swf" />
	<param name="quality" value="high" />
	<param name="bgcolor" value="#ffffff" />	
	<param name="FlashVars" value="itemID=<?php print "$id"; ?>&itemCode=<?php print "$code"; ?>">
	<embed src="AS3_php_2_Var_into_flash.swf" FlashVars="itemID=<?php print "$id"; ?>&itemCode=<?php print "$code"; ?>" quality="high" bgcolor="#ffffff" width="400" height="150" name="AS3_php_2_Var_into_flash" align="middle" allowScriptAccess="sameDomain" allowFullScreen="false" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
	</object>
</noscript>
</body>
</html>
