This tutorial is documented on Google with a creation
date of January 24th 2009, created by Adam Khoury.
-----------------------------------------------------

1.This application must be on a PHP enabled server,
or else you will not see the rendered text fields.

2.And you must use the index.php code structure for FlashVars 
to make it work.


Have a ball!

~Adam Khoury @ Flash Building