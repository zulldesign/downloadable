
Redistribution of this application is prohibited.
-------------------------------------------------

This application has been custom coded in ActionScript 3.0 by
Adam Khoury @ FlashBuilding.com Web Development Studio.

You are free to use this application in your personal projects. 

For possible code help join the forum @ www.developphp.com and 
ask in the Flash AS3 forum.


-------------------------------------------------
Creatives Policy notes:

Commercial distribution of these files is prohibited.
Offering these files for download on any of your web sites is prohibited.
