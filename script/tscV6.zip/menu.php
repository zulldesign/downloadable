<table border="0" width="100%" cellpadding="5" cellspacing="0" align="center" bgcolor="#ffcc66">
	<tr>
		<td align="center" valign=top>
			<font size="3">
				:<a href="index.php?a=register">Create new  Store Admin Account</a>:
				:<a href="index.php?a=login">Login as Store Admin for already setup store</a>:
			</font>
		</td>
	</tr>
</table>