<table border="0" width="100%" cellpadding=10 cellspacing=0 align="center">
  <tr>
    <td nowrap="nowrap" align="left">
			<h1 align="left">TSC - The Store Creator</h1>
			<h2 align="left">PHP/MySQL Store creator application with PayPal IPN Shopping Cart</h2>
		</td>
		<td align="center" valign="middle">
			<p>&nbsp;</p>
		</td>
  </tr>
</table>
