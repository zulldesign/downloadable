<table border=0 cellspacing=0 cellpadding=0 width="100%" align="center" bgcolor="#cccccc">
	<tr>
		<td>
			<font size=1 color=black>
				<p align="center">Powered by <a href="http://www.monitor-line.com" target="_blank">TSC (The Store Creator)</a>  </p>
			</font>
		</td>
	</tr>

</table>
