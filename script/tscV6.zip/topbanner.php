<!-- Top banner panel in the main admin area -->
<p>&nbsp;</p>