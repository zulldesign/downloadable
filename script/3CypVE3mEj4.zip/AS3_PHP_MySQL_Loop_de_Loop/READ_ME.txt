This application must be on a PHP and MySQL enabled server to operate.

You must also connect to your MySQL database connection file on server 
in the upper portion of my PHP script. Or you can put your full connection
data straight into my file instead of "including" an external connection file
like I did in this lesson example.