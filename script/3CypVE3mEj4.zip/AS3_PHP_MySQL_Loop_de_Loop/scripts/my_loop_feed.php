<?php
if ($_POST['requester'] == "adam") {
	// Connect to database
	include_once "connect_to_mysql.php";	
	$body = "";
	$sql = mysql_query("SELECT id, firstname, sign_up_date FROM myMembers WHERE email_activated='1' ORDER BY id ASC LIMIT 10");

	while($row = mysql_fetch_array($sql)){

		$id = $row["id"];
		$firstname = $row["firstname"];
		$sign_up_date = $row["sign_up_date"];
		$sign_up_date = strftime("%b %d, %y", strtotime($sign_up_date));
		$body .= '<u><font color="#0000CC"><a href="profile.php?id=' . $id. '" target="_self">' . $firstname . '</a></font></u>    |    <font color="#FF0000">' . $id . '</font>      |      <font color="#9B9B9B">' . $sign_up_date . '</font><br /><br />';

    }
    echo "returnBody=$body";
    mysql_close();
    exit();
} 
?>