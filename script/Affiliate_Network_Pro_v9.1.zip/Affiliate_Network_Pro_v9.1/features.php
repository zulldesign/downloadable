	<table width="239" border="0" align="center" cellpadding="0" cellspacing="0">
		<tr>
			<td valign="middle" style="background-image:url(images/language-bg.jpg); background-repeat:no-repeat; height:104px; background-position:center;">
				<div class="langSelect"><? include_once "language_select.php"; ?></div>	
			</td>
		</tr>
		<tr>
			<td height="5"></td>
		</tr>
		<tr>
			<td align="center"><img src="images/features-login-top.jpg" width="239" height="44" /></td>
		</tr>
		<tr>
		  <td bgcolor="#f7f7f7">
			<table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
				  <tr>
					<td colspan="2" align="center">&nbsp;</td>
				  </tr>
				  <tr>
					<td width="15%" height="25" align="center"><img src="images/bullet.jpg" width="8" height="10" /></td>
					<td width="75%" align="left" class="text-02"><?=$featurelistnew?></td>
				  </tr>
				  <tr>
					<td height="25" align="center"><img src="images/bullet.jpg" width="8" height="10" /></td>
					<td align="left" class="text-02"><?=$featurelistnew1?></td>
				  </tr>
				  <tr>
					<td height="25" align="center"><img src="images/bullet.jpg" width="8" height="10" /></td>
					<td align="left" class="text-02"><?=$featurelistnew2?></td>
				  </tr>
				  <tr>
					<td height="25" align="center"><img src="images/bullet.jpg" width="8" height="10" /></td>
					<td align="left" class="text-02"><?=$featurelistnew3?></td>
				  </tr>
				  <tr>
					<td height="25" align="center"><img src="images/bullet.jpg" width="8" height="10" /></td>
					<td align="left" class="text-02"><?=$featurelistnew4?></td>
				  </tr>
				  <tr>
					<td height="25" align="center"><img src="images/bullet.jpg" width="8" height="10" /></td>
					<td align="left" class="text-02"><?=$featurelistnew5?></td>
				  </tr>
				  <tr>
					<td height="25" align="center"><img src="images/bullet.jpg" width="8" height="10" /></td>
					<td align="left" class="text-02"><?=$featurelistnew6?></td>
				  </tr>
				  <tr>
					<td height="25" align="center"><img src="images/bullet.jpg" width="8" height="10" /></td>
					<td align="left" class="text-02"><?=$featurelistnew7?></td>
				  </tr>
				  <tr>
					<td height="25" align="center"><img src="images/bullet.jpg" width="8" height="10" /></td>
					<td align="left" class="text-02"><?=$featurelistnew8?></td>
				  </tr>
				  <tr>
					<td colspan="2" align="center">&nbsp;</td>
				  </tr>
				</table>
			</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
	</table>
	<script language="javascript" type="text/javascript">
		function viewlink(){
			url	= "forgotpass.php";
			nw = open(url,'new','height=200,width=450,scrollbars=yes');
			nw.focus();
		}
	</script>				