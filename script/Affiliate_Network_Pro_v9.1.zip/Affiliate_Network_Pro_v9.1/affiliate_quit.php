<?php

    include 'includes/session.php';
        session_destroy();
        $Err        = $aff_quit;
        header("Location:index.php?Act=Affiliates&Err=$Err");
    exit;
?>