<table width="661" border="0" cellspacing="0" cellpadding="0" align="center">
	<tr>
		<td class="affiliates-reg-top"><div class="box-heading">&nbsp;&nbsp;&nbsp;<?=$lang_merPay?></div></td>
	</tr>
	<tr>
		<td class="affiliate-reg-content-bg">
			<table width="90%"  border="0" align="center" cellpadding="0" cellspacing="0">
				<tr>
				<td height="100%" rowspan="2" align="left" valign="top">
				<table width="100%" border="0" align="left" cellpadding="0" cellspacing="0">
				<tr>
				<td height="2" colspan="2"  align="center">
				<br/>
				<? include_once "paymoney.php"; ?>
				</td>
				</tr>
				</table></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td><img src="images/affiliate-reg-bottom.jpg" width="661" height="13" /></td>
	</tr>
</table>