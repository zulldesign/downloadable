
  <div align="center">
    <center>
        <p>&nbsp;</p>
        <p><font size="4"><?=$addlinks_nolink?></font> </p>
<table width="719" border="0" align="center" cellpadding="0" cellspacing="0"  class="tablebdr" style="border-collapse: collapse; text-align: center; ">
      <tr>
      <!--  <td width="738" rowspan="3" class="tdhead">&nbsp;</td> -->
        <td width="130" class="tdhead"><b>
                <?=$laddban_Text?></b></td>
        <td width="5">&nbsp;</td>
        <td width="130" class="tdhead">
                <b><?=$laddban_Banner?></b></td>
       <td width="5" valign="top" style="text-align: left">&nbsp;</td>
        <td width="130" class="tdhead"><b><?=$laddban_Flash?></b></td>
		<td width="6" valign="top" style="text-align: left">&nbsp;</td>
        <td width="130" class="tdhead"><b><?=$laddban_HTML?></b></td>
        <td width="4">&nbsp;</td>
        <td width="130" class="tdhead"><b>
  <?=$laddban_Popupads?></b></td>
        <td width="4">&nbsp;</td>
		<td width="167" class="tdhead"><b><?=$lpgm_temptext?></b></td>
      </tr>
      <tr>
        <td width="130" valign="top" style="text-align: left">&nbsp;<?=$laddban_Texttext?><br/>&nbsp;</td>
        <td width="5" valign="top" style="text-align: left">&nbsp;</td>
        <td width="130" valign="top" style="text-align: left">&nbsp;<?=$laddban_Bannertext?><br/>&nbsp;</td>
       <td width="5" valign="top" style="text-align: left">&nbsp;</td>
        <td valign="top" style="text-align: left"><?=$lFlash_caption?> &nbsp; </td>
		<td width="6">&nbsp;</td>
        <td width="130" valign="top" style="text-align: left">&nbsp;<?=$laddban_HTMLtext?></td>
        <td width="4" valign="top" style="text-align: left">&nbsp;</td>
        <td width="130" valign="top" style="text-align: left">&nbsp;<?=$laddban_Popupadstext?></td>
		<td width="4" valign="top" style="text-align: left">&nbsp;</td>
        <td width="167" valign="top" style="text-align: left">&nbsp;<?=$laddban_TemplateAdtext?></td>
      </tr>

	  
      <tr bgcolor="#DEE5EB">
        <td width="130" ><a href="index.php?Act=add_text">
                      <img src='images/text.jpg'  border='0'  alt=""/></a></td>
        <td width="5">&nbsp;</td>
        <td width="130"><a href="index.php?Act=add_banner">
                      <img src='images/graphic.jpg'  border='0'  alt=""/></a></td>
        <td width="5">&nbsp;</td>
      <td width="130"> <a href="index.php?Act=add_flash">
                      <img src='images/flash.jpg'  border='0'  alt=""/></a></td>
        <td width="6">&nbsp;</td>
        <td width="130">
                      <a href="index.php?Act=add_html">
                      <img src='images/html.jpg'  border='0'  alt=""/></a></td>
        <td width="4">&nbsp;</td>
        <td width="130">
                  <a href="index.php?Act=add_popup">
                      <img src='images/pop.jpg'  border='0'  alt=""/></a></td>
        <td width="4">&nbsp;</td>
		<td width="167">&nbsp;<a href="index.php?Act=add_textnew">
                      <img src='images/temp_text.jpg'  border='0'  alt=""/></a></td>
      </tr>

      <tr>
        <td class="tdhead" colspan="11">&nbsp;</td>
      </tr>
    </table>
    </center>
  </div>

<br/>

<form name='form1' method='post' action=''>

</div>