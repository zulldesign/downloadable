<?
  include_once '../includes/constants.php';
  include_once '../includes/functions.php';
  include_once '../includes/session.php';
   include_once '../includes/allstripslashes.php';


    $partners=new partners;
    $partners->connection($host,$user,$pass,$db);

	include_once 'language_include.php';

	$bal		=	$_SESSION['MERCHANTBALANCE'];
    $mid		=	$_SESSION['MERCHANTID'];
    $amount	   	=   $_GET['amount'];
    $grandtotal	= 	$bal + $amount;

   // echo $grandtotal."tot";

//----------------------------------  security -------------------------------------------------------------//
		$secid         = $_GET['secid'];
    	$secpass       = $_GET['secpass'];

	  $secsql	= "select * from random_gen where rand_genid='".addslashes($secid)."' and rand_genpwd='".addslashes($secpass)."'";
      $secres=mysql_query($secsql);
      if(mysql_num_rows($secres)>0)
      {

	          $secdel ="delete from random_gen where rand_genid='".addslashes($secid)."' and rand_genpwd='".addslashes($secpass)."'";
	       	  mysql_query($secdel);

      }
      else
      {
		$msg=$lang_perror;
        header("location:index.php?Act=add_money&msg=$msg");
         exit;

      }
// ----------------------------- security test end ------------------------------------------//


    $sql		="UPDATE `merchant_pay` SET `pay_amount` = '$grandtotal' WHERE `pay_merchantid` = '$mid'";
    mysql_query($sql);




    //------------------------code added by rakhi------------------------------//

          //-----------------payment------------------------------------------//

          	 	$today=date("Y-m-d");
           		$sql3  = "INSERT INTO `partners_adjustment` ( `adjust_id` , `adjust_memberid` , `adjust_action` , `adjust_flag`,`adjust_amount`,`adjust_date` )  ";
           		$sql3 .= "VALUES ('', '$mid', 'deposit', 'm','$amount','$today')";
           		mysql_query($sql3);

          //------------------------------------------------------------------//

          //-------making approved---------------------------------------------//

          	   if($grandtotal>$minimum_amount)
               {
                  $sql        ="UPDATE `partners_merchant` SET merchant_status='approved' where `merchant_id` = '$mid'";
        		  mysql_query($sql);
               }

          //-------------------------------------------------------------------//


    //-------------------------------------------------------------------------//



        $_SESSION['MERCHANTBALANCE']	=	$grandtotal;
        $msg         = $lang_add_success_message ;
        header("location:index.php?Act=add_money&msg=$msg");
        exit;
?>