
                          <br/>
                              <table border="0" cellpadding="0"   width="90%" class="tablebdr"  align="center">
                              <tr>
                                  <td width="100%" height="26" colspan="4"></td>
                             </tr>
                             <tr>
                               <td width="100%" height="26" align= "center" ><p><b><?=$lgetcode_HelpTrackingCodeforLead?><p></b></td>
                              <tr>
                               <td width="100%" height="40" align= "center" ><p><?=$lgetcode_text1?></td>
                              </tr>
                              <tr>
                              <td width="100%" height="26" align= "center" ><p><b><p></b></td>
                              <tr>
                              <td width="100%" height="26" align= "center" ><p><b><?=$lgetcode_HelpTrackingCodeforSale?></b></td>
                              <tr>

                                    <td width="100%" align= "center" ><?=$lgetcode_text2?></td>
                               </tr>
                               <tr>
                                  <td width="100%" height="26" colspan="4">&nbsp;</td>
                             </tr>
                               </table>
                                 <!-- close table 3-->