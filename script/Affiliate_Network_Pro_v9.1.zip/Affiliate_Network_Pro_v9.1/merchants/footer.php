<?php /*?><table cellpadding="0" cellspacing="0" width="100%">
    	 <tr>
            <td height="10" ><div align="center"><p>&nbsp;</p></div></td>
          </tr>
          <tr>
            <td height="30" bgcolor="#FFCC66"><div align="center"><span class="af"><a href="index.php?Act=home"><?=$lang_Home?></a> | <a href="index.php?Act=accounts"><?=$lang_Accounts?></a> | <a href="index.php?Act=programs"><?=$lang_Programs?></a> | <a href="index.php?Act=affiliates&amp;status=all"><?=$lang_Affiliates?></a> | <a href="index.php?Act=emails"><?=$lang_Emails?></a> | <a href="index.php?Act=AffiliateReport">
            <?=$lang_report_affiliate?>
            </a> | <a href="index.php?Act=group"><?=$lang_Groups?></a> <br/>
            <a href="index.php?Act=daily"><?=$lang_Reports?></a> | <a href="index.php?Act=forperiod">
     <?=$lang_report_forperiod?>
     </a> | <a href="index.php?Act=ProgramReport">
     <?=$lang_report_pgm?>
     </a> | <a href="index.php?Act=LinkReport"><?=$lang_report_link?>
     </a> | <a href="../merchant_quit.php"><?=$lang_Quit?></a>  </span></div></td>
          </tr>
          <tr>
            <td height="25"><div align="center">Copyright 2004 &copy; AlstraSoft Affiliate Network Pro. All Rights Reserved.</div></td>
          </tr>
        </table><?php */?>
		
	<table cellpadding="0" cellspacing="0" width="100%">
		<tr>
			<td height="10" ><div align="center"><p>&nbsp;</p></div></td>
		</tr>
		<tr>
			<td height="30" ><div align="center">
			<a href="index.php?Act=home" class="link-01"><?=$lang_Home?></a> | 
			<a href="index.php?Act=accounts"><?=$lang_Accounts?></a> | 
			<a href="index.php?Act=programs"><?=$lang_Programs?></a> | 
			<a href="index.php?Act=affiliates&amp;status=all"><?=$lang_Affiliates?></a> | 
			<a href="index.php?Act=emails"><?=$lang_Emails?></a> | 
			<a href="index.php?Act=AffiliateReport"><?=$lang_report_affiliate?></a> | 
			<a href="index.php?Act=group"><?=$lang_Groups?></a> <br/>
			<a href="index.php?Act=daily"><?=$lang_Reports?></a> | 
			<a href="index.php?Act=forperiod"><?=$lang_report_forperiod?></a> | 
			<a href="index.php?Act=ProgramReport"><?=$lang_report_pgm?></a> | 
			<a href="index.php?Act=LinkReport"><?=$lang_report_link?></a> | 
			<a href="../merchant_quit.php"><?=$lang_Quit?></a></div></td>
		</tr>
		<tr>
			<td height="25" align="center"><div>Copyright 2009 &copy; Affiliate Network Pro</div></td>
		</tr>
	</table>		
