<?php	ob_start();

   /***************************************************************************************************
     PROGRAM DESCRIPTION :  PROGRAM TO VIEW FORPERIOD REPORTS  (PROCESS PAGE)
      VARIABLES          :   click		=total click amnt
   			  				 lead		=total lead amnt
    						 sale		=total sale amnt
    						 subsale	=total subsale amnt
    						 nclick		=total no of clicks
   						     nlead      =total no of leads
   							 nsale      =total no of sales
   							 nsubsale   =total no of subsales
                             MerchantID =MERCHANT ID
                             from		=from date
    						 to			=to date
                             Cfrom		=from CONVERTED date
    						 Co			=to CONVERTED  date
                             msg	  	=errmsg
                             sub		=get submit button
  //*************************************************************************************************/

  include_once '../includes/constants.php';
  include_once '../includes/functions.php';
  include_once '../includes/session.php';
   include_once '../includes/allstripslashes.php';

  include_once "paymentsforsel.php";

   $partners=new partners;
   $partners->connection($host,$user,$pass,$db);

   	include_once 'language_include.php';

   /***********************variables*******************************************/
   $MERCHANTID      =$_SESSION['MERCHANTID'];               //merchantid
   $cfrom           =trim($_POST['txtfrom']);               //from date
   $cto             =trim($_POST['txtto']);                 //to date
   $sub             =trim($_POST['sub']);                   //submuit button
   $currValue       = $_POST['currValue'];
   /***************************************************************************/

   /**************************validation***************************************/
   if(!$partners->is_date($cfrom) || !$partners->is_date($cto) )
   {
    $Err=$lang_report_err;
    header("location:index.php?Act=forperiod&err=$Err");
    exit;
   }
   $From                     =$partners->date2mysql($cfrom);  //changing date format
   $To                       =$partners->date2mysql($cto);
   /***************************************************************************/


   $sql             = "SELECT * from partners_joinpgm j,partners_program p where program_merchantid='$MERCHANTID' and  j.joinpgm_programid=p.program_id   ";
   $result1         = mysql_query($sql);
   $total           = GetPaymentDetails($sql,$To,$From,$currValue,$default_currency_caption);


    # calculate impressions
    $impSql = " SELECT sum(imp_count) AS impr_count FROM partners_impression_daily WHERE imp_merchantid = '$MERCHANTID' AND imp_date BETWEEN '$From' and '$To' ";
    $impRet	= mysql_query($impSql);
	$row_impr = mysql_fetch_object($impRet);
	$numRec = $row_impr->impr_count;
	if($numRec == '') $numRec = 0;

    $rawClick = GetRawTrans('click', $MERCHANTID, 0, 0, 0,  $From,$To, 0)   ;
    $rawImp   = GetRawTrans('impression', $MERCHANTID, 0, 0, 0,  $From,$To, 0)   ;

    //initiating
    $click          =0;
    $lead           =0;
    $sale           =0;
    $nclick         =0;
    $nlead          =0;
    $nsale          =0;
   $impression_amt 			 =0;
   $impression               =0;
   $impression_counts        =0;



    while($rows=mysql_fetch_object($result1))
    {
       $joinid=$rows->joinpgm_id;


            $sql       = "SELECT * from partners_transaction where transaction_dateoftransaction between '$From' and '$To' and transaction_type='click' and transaction_joinpgmid='$joinid'";
            $result    = @mysql_query($sql);
            $nclick    = @mysql_num_rows($result)+$nclick;   //no of click
            while($row=mysql_fetch_object($result))
            {
               # get transaction details
    	       $date         =   $row->transaction_dateoftransaction;
	           $affAmnt      =   $row->transaction_amttobepaid;
	           $adminAmnt    =   $row->transaction_admin_amount;

	           # converting to user currency
	           if($currValue != $default_currency_caption){
	                $affAmnt     =   getCurrencyValue($date, $currValue, $affAmnt);
	                $adminAmnt   =   getCurrencyValue($date, $currValue, $adminAmnt);
	           }
	            $click                =$affAmnt + $adminAmnt + $click;  //lead amnt
            }

            $sql      = "SELECT * from partners_transaction where transaction_dateoftransaction between '$From' and '$To' and transaction_type='lead' and transaction_joinpgmid='$joinid'";
            $result   = @mysql_query($sql);
            $nlead    = @mysql_num_rows($result)+$nlead;  //no of lead
            while($row=mysql_fetch_object($result))
            {
                # get transaction details
      	       $date         =   $row->transaction_dateoftransaction;
	           $affAmnt      =   $row->transaction_amttobepaid;
	           $adminAmnt    =   $row->transaction_admin_amount;

	           # converting to user currency
	           if($currValue != $default_currency_caption){
	                $affAmnt     =   getCurrencyValue($date, $currValue, $affAmnt);
	                $adminAmnt   =   getCurrencyValue($date, $currValue, $adminAmnt);
	           }
	            $lead            = $affAmnt + $adminAmnt + $lead;  //lead amnt
            }

            $sql      = "SELECT *  from partners_transaction where transaction_dateoftransaction between '$From' and '$To' and transaction_type='sale' and transaction_joinpgmid='$joinid'";
            $result   = mysql_query($sql);
            $nsale    = mysql_num_rows($result)+$nsale; //no of sale
            while($row=mysql_fetch_object($result))
            {
             # get transaction details
      	       $date         =   $row->transaction_dateoftransaction;
	           $adminAmnt    =   $row->transaction_admin_amount;
		//Modified on 23-JUNE-06 for Recurring Sale Commission by SMA
				 $transactionId	= $row->transaction_id;
				 $recur 	 = 	$row->transaction_recur;

				  // If the sale commission is of recurring type
				 if($recur == '1')
				 {
					$sql_Recur 	= "SELECT * FROM partners_recur WHERE recur_transactionid = '$transactionId' ";
					$res_Recur	= mysql_query($sql_Recur);
					if(mysql_num_rows($res_Recur) > 0)
					{
						$row_recur	= mysql_fetch_object($res_Recur);
						$recurId	= $row_recur->recur_id;

						$sql_recurpay	= "SELECT * FROM partners_recurpayments WHERE recurpayments_recurid = '$recurId' ";
						$res_recurpay	= mysql_query($sql_recurpay);
						if(mysql_num_rows($res_recurpay) > 0)
						{
							$row_recurpay 	= mysql_fetch_object($res_recurpay);
							$affAmnt 	 =  $row_recurpay->recurpayments_amount;
						}
					}
				 }
				 else
				 {
		// END Modified on 23-JUNE-06
			           $affAmnt      =   $row->transaction_amttobepaid;
				 }

	           # converting to user currency
	           if($currValue != $default_currency_caption){
	                $affAmnt     =   getCurrencyValue($date, $currValue, $affAmnt);
	                $adminAmnt   =   getCurrencyValue($date, $currValue, $adminAmnt);
	           }
	            $sale                =$affAmnt + $adminAmnt + $sale;  //lead amnt
            }  //end  while




   ##== Modified on JuNE.17.06 by SMA to calculate impression commission
	        $sql       = "SELECT * from partners_transaction where transaction_dateoftransaction between '$From' and '$To' and transaction_type='impression' and transaction_joinpgmid='$joinid'";
	        $result    = @mysql_query($sql);

	        while($row=mysql_fetch_object($result))
	        {
            	# get transaction details
	            $date         =   $row->transaction_dateoftransaction;
	            $affAmnt      =   $row->transaction_amttobepaid;
	            $adminAmnt    =   $row->transaction_admin_amount;
	            $trans_id     =   $row->transaction_id;
	            #get the impressioncount(unit) from trans_rates table
	            $sql_rate     = "SELECT trans_unit FROM partners_trans_rates WHERE trans_id ='$trans_id'";
	            $res_rate     = mysql_query($sql_rate);

	            if(mysql_num_rows($res_rate) >0)
	            {
  	                while($row  = mysql_fetch_object($res_rate))
	                {
	                	$impression_counts  += $row->{trans_unit};
	                }
	            }

	            # converting to user currency
	            if($currValue != $default_currency_caption)
                {
                	$affAmnt     =   getCurrencyValue($date, $currValue, $affAmnt);
	                $adminAmnt   =   getCurrencyValue($date, $currValue, $adminAmnt);
	            }

	            $impression                =$affAmnt + $adminAmnt + $impression;  //impression amnt
	        }

   ##== End of Modification on JuNE.17.06 by SMA to calculate impression commission

    }
    // end while  1
   $click   =  number_format($click,2);
   $lead 	= number_format($lead,2);
   $sale   = number_format($sale,2);

   $sale           =$sale."~".number_format($subsale,2)."~".$nsubsale."~".$numRec."~".$rawClick."~".$rawImp."~".number_format($impression,2)."~".$pending_impAmt;
   header("location:index.php?Act=forperiod&click=$click&nclick=$nclick&lead=$lead&nlead=$nlead&sale=$sale&nsale=$nsale&merchant=$Merchant&affiliate=$Affiliate&from=$cfrom&to=$cto&sub=$sub&total=$total");
   exit;


?>