<?php /*?><table width="775" border="0" cellspacing="0" cellpadding="0" align="center" class="outtbl">
  <tr>
    <td width="208" height="43"><img src="images/footer_14.gif" width="208" height="43" alt=""/></td>
    <td width="31" height="43"><img src="images/footer_15.gif" width="31" height="43" alt=""/></td>
    <td height="43" align="center" valign="bottom" class="footbg" ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td height="100%" align="center" class="style2">
		  <a href="index.php"><?=$lang_Home?></a> | 
		  <a href="index.php?Act=Merchants" ><?=$lang_Merchants?></a> | 
		  <a href="index.php?Act=Affiliates" ><?=$lang_Affiliates?></a> | 
		  <a href="index.php?Act=directory" class="ab"><?=$lang_Directory?></a> | 
		  <a href="index.php?Act=login" ><?=$lang_Login?></a> | 
		  <a href="index.php?Act=aboutus"><?=$lang_About?></a> | 
		  <a href="index.php?Act=contactus"><?=$lang_Contact?></a></td>
        </tr>
        <tr>
          <td height="20"><div align="center" class="style2"><?=$lang_copyright?></div></td>
        </tr>
    </table></td>
  </tr>
</table>
<?php */?>

	<table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
		<tr>
			<td height="30">&nbsp;</td>
		</tr>
		<tr>
			<td align="center" class="footer_sep">
				<a href="index.php" class="footer_links"><?=$lang_Home?></a>   &nbsp;&nbsp;|&nbsp;&nbsp;   
				<a href="index.php?Act=Merchants" class="footer_links"><?=$lang_Merchants?></a>&nbsp;&nbsp;   |    &nbsp;&nbsp;
				<a href="index.php?Act=Affiliates" class="footer_links"><?=$lang_Affiliates?></a>&nbsp;&nbsp;    |&nbsp;&nbsp;   
				<a href="index.php?Act=directory" class="footer_links"><?=$lang_Directory?></a>&nbsp;&nbsp;   |&nbsp;&nbsp;    
				<a href="index.php?Act=login" class="footer_links"><?=$lang_Login?></a>&nbsp;&nbsp;    |   &nbsp;
				<a href="index.php?Act=aboutus" class="footer_links"><?=$lang_About?></a>    &nbsp;&nbsp;|&nbsp;&nbsp;   
				<a href="index.php?Act=contactus" class="footer_links"><?=$lang_Contact?></a> 
			</td>
	</tr>
	<tr>
	<td height="30" align="center" class="footer_sep">Copyright 2009 &copy; Affiliate Network Pro</td>
	</tr>
	</table>