<?php
  /***************************************************************************************************
     PROGRAM DESCRIPTION :  PROGRAM TO CLOSE ADMIN SESSION
  //*************************************************************************************************/


 include '../includes/session.php';
 include '../includes/constants.php';
 include '../includes/functions.php';
 include_once '../includes/allstripslashes.php';

 $partners=new partners;
 $partners->connection($host,$user,$pass,$db);
  //Added for admin session update
            	$ip	= $_SERVER['REMOTE_ADDR'];
		if($_SESSION['ADMINUSERID'] == '1')
		{				
	            $sql = "UPDATE `partners_admin` SET `admin_ip` = '$ip',";
	            $sql .= " `admin_lastLogin` =''";
                mysql_query ($sql);
		} 
		$sql = "UPDATE `partners_adminusers` SET `adminusers_ip` = '$ip',";
		$sql .= " `adminusers_lastLogin` ='' WHERE adminusers_id='".$_SESSION['ADMINUSERID']."' ";

		mysql_query ($sql);
		echo mysql_error();
		
 //End of admin session update
	session_destroy();
    $Err	="ad1003";
	header("Location:index.php?Err=$Err");
    exit;
?>