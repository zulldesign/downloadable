<?php	ob_start();
#-------------------------------------------------------------------------------
# Mercahnt Payment Form
# Payment suceess form

# Pgmmr           : RR
# Date Created :   28-11-2004
# Date Modfd   :   28-11-2004
#-------------------------------------------------------------------------------

#----------------------------------------------------------------------------
#  file including
#----------------------------------------------------------------------------
  include_once '../includes/constants.php';
  include_once '../includes/functions.php';
  include_once '../includes/session.php';
  include_once '../includes/allstripslashes.php';

#----------------------------------------------------------------------------
# establishing connection
#----------------------------------------------------------------------------
    $partners =  new partners;
    $partners->connection($host,$user,$pass,$db);

# getiing merchant id and amount
	$id = intval($_GET['id']);

# get mode (for reject)
	$mode	= $_GET['mode'];
    if($mode=="reject")
    {
    	//update status
        $sql = "UPDATE partners_addmoney SET addmoney_status = 'suspend' WHERE addmoney_id = '$id'";
        mysql_query($sql);

        //redirect back to listing page
        header("location:index.php?Act=mer_requests");
        exit;
    }

# get details
    $newSql = "SELECT * FROM partners_addmoney WHERE addmoney_id = '$id' ";
    $newRet = mysql_query($newSql);

    if(mysql_num_rows($newRet)>0){
    	$merRow   = mysql_fetch_object($newRet);
        $mid	  = $merRow->addmoney_merchantid;
        $amount   = $merRow->addmoney_amount;
        $mode	  = $merRow->addmoney_mode;
        $merchant_sql ="SELECT * FROM   merchant_pay  WHERE pay_merchantid='$mid'";
	    $merchant_ret =mysql_query($merchant_sql);

	    if(mysql_num_rows($merchant_ret)>0) {
	          $row        = mysql_fetch_object($merchant_ret);
	          $grandtotal = $row->pay_amount;
	    }

        $grandtotal  = $grandtotal +  $amount;

        $sql = "UPDATE partners_addmoney SET addmoney_status= 'approved' WHERE addmoney_id = '$id'";
        mysql_query($sql);

        $sql = "UPDATE `merchant_pay` SET `pay_amount` = '$grandtotal' WHERE `pay_merchantid` = '$mid'";
        mysql_query($sql);



         $today=date("Y-m-d");
         $sql3  = "INSERT INTO `partners_adjustment` ( `adjust_id` , `adjust_memberid` , `adjust_action` , `adjust_flag`,`adjust_amount`,`adjust_date` )  ";
         $sql3 .= "VALUES ('', '$mid', 'deposit', 'm','$amount','$today')";
         mysql_query($sql3);

         if($grandtotal>$minimum_amount)
         {
           $sql  = "UPDATE `partners_merchant` SET merchant_status='approved' where `merchant_id` = '$mid'";
           mysql_query($sql);
         }else{
           $sql  = "UPDATE `partners_merchant` SET merchant_status='empty' where `merchant_id` = '$mid'";
            mysql_query($sql);
         }

        # make user advance
        if($mode == "upgrade"){
             $sql = "UPDATE partners_merchant SET merchant_type = 'advance' WHERE merchant_id = '$mid' ";
             mysql_query($sql);
        }
    }

$msg  = "Payment Successful";
header("location:index.php?Act=mer_requests&msg=$msg");

?>