	<table  width="100%" border="0">
	  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="right" width="4"><img src="images/topbar-left.jpg" width="4" height="22" /></td>
    <td class="top-bar-tile">&nbsp;</td>
    <td align="left" width="4"><img src="images/topbar-right.jpg" width="4" height="22" /></td>
  </tr>
</table>
</td>
  </tr>
	  <tr>
		<td width="100%" align="center" height="57">&nbsp;
		<font color="#ff0000" size="2"><? echo $$Err?></font></td>
	  </tr>

      <!--!!!!!!!!!!!!!!!!!!!!!!!!!!!!Login Form!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!-->
      <tr>
      <td colspan="3">
	  <form method="post" action="admin_login_validate.php">
      <table  width="100%" class="tablewbdr" border="0">
	      <tr>
	        <td width="24%" align="right" height="36"><span class="style1"><font size="2">UserName &nbsp;&nbsp;</font></span></td>
	        <td width="1%" align="right" height="36">&nbsp;</td>
	        <td width="21%" align="right" height="36">
	          <div align="left">
	            <input type="text" name="login" size="20" />
	          </div></td>
	      </tr>
	      <tr>
	        <td width="24%" align="right" height="42"><span class="style1"><font size="2">Password&nbsp;&nbsp;&nbsp;&nbsp;</font></span></td>
	        <td width="1%" align="right" height="42">&nbsp;</td>
	        <td width="21%" align="right" height="42">
	          <div align="left">
	            <input type="password" name="passwd" size="20" />
	          </div></td>
	      </tr>
	      <tr>
	        <td width="25%" align="right" height="26" colspan="2" >&nbsp;    </td>
	        <td width="21%" align="right" height="26"><div align="left">
	          <input type="submit" value="Login" name="B1" />
	        </div></td>
	      </tr>
      </table>
      </form>
      </td>
      </tr>
	  <tr>
		<td width="100%" align="right" height="180" colspan="3">&nbsp;</td>
	  </tr>
	  <tr>
<!--		<td align="right" colspan="3" height="20" bgcolor="#FFCC66" ><div align="center"><span class="af" >
		  Copyright 2004 &copy; AlstraSoft Affiliate Network Pro. All Rights Reserved.</span></div></td>
	  </tr>-->
	    <tr>
    <td align="center" class="footer-bg"><div>Copyright 2009 &copy; Affiliate Network Pro</div></td>
  </tr>

	  </table>
 	</td>
   </tr>
</table>
</body>
</html>