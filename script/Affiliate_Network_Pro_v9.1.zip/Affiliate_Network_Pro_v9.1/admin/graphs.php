<?php
/************************************************************************/
/*     PROGRAMMER     :  SMA                                            */
/*     SCRIPT NAME    :  graphs.php             			            */
/*     CREATED ON     :  15/JULY/2006                                   */

/*	 Page to acces the graphs section 	based on the privileges granted */
/************************************************************************/
	$userobj = new adminuser();
	$adminUserId = $_SESSION['ADMINUSERID'];


?>