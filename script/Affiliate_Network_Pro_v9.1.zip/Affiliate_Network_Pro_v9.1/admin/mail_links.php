<table cellpadding="0" cellspacing="0"  width="100%"   class="tablewbdr" height="18">

  <tr>
    <td width="82%"  align="right" height="18">
  </tr>
  <tr>
    <td width="18%" class="tdhead" align="right" height="18">
     [<a href="index.php?Act=event">Add &amp; Remove Events</a>]
  </tr>
</table>