<table cellpadding="0" cellspacing="0"  width="100%"   class="tablewbdr">

  <tr>
    <td width="100%" class="tdhead" align="right">
     [<a href="index.php?Act=transaction_merchant">Revenues Through <?=$title?></a>]
     [<a href="index.php?Act=revenues">All Revenues</a>]</td>
     </tr>
</table>
<br/>