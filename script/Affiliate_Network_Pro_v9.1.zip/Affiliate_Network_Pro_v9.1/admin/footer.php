<!--<div align="center">Copyright 2004 &copy; AlstraSoft Affiliate Network Pro. All Rights Reserved.</div>-->

<div>Copyright 2009 &copy; Affiliate Network Pro</div>