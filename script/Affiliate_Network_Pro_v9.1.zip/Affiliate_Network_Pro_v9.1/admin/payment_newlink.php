
 <table cellpadding="0" cellspacing="0"  width="100%"   class="tablewbdr">

  <tr>
    <td width="100%" class="tdhead" align="right">

      [<a href="index.php?Act=payment_list">Affiliate Commission Payments</a>]
      [<a href="index.php?Act=payment_adminlist">Admin Commission Payments</a>]
      [<a href="index.php?Act=payment_2ndlist">2ndtire Commission Payments</a>]
      [<a href="index.php?Act=payment_reverselist">Reverse Sale Payments</a>]
      [<a href="index.php?Act=manual_payments">Manual Payments</a>]
      [<a href="index.php?Act=paid_mails">Paid Mails</a>]
  </tr>

</table>
<?
?>