

  <div align="center">
    <center>
        <p>&nbsp;</p>
        <p><font size="4">No Links Added to This Program </font> </p>
        <table border='0' cellpadding="0" cellspacing="0" style="border-collapse: collapse; text-align: center" bordercolor="#111111" width="719" id="AutoNumber2" class="tablebdr">
      <tr>
        <td width="5" class="tdhead">&nbsp;</td>
        <td width="137" class="tdhead"><b>
                Text</b></td>
        <td width="5">&nbsp;</td>
        <td width="142" class="tdhead">
                <span lang='bg'><b>Banner</b></span></td>
        <td width="5">&nbsp;</td>
        <td width="138" class="tdhead"><b>
                Flash</b></td>
        <td width="5">&nbsp;</td>
        <td width="138" class="tdhead"><b>HTML</b></td>
        <td width="5">&nbsp;</td>
        <td width="145" class="tdhead"><b>
  Pop-up ads</b></td>
        <td width="13" class="tdhead">&nbsp;</td>
      </tr>
      <tr>
        <td width="5" valign="top">&nbsp;</td>
        <td width="137" valign="top" style="text-align: left">&nbsp;<span lang='bg'>Create your text ads here. The advertising link will be a text and
        description under the link.</span><br/>&nbsp;</td>
        <td width="5" valign="top" style="text-align: left">&nbsp;</td>
        <td width="142" valign="top" style="text-align: left">&nbsp;Create your banner&nbsp;
        ads here. The supported formats are .gif , .jpg, .png .<br/>&nbsp;</td>
        <td width="5" valign="top" style="text-align: left">&nbsp;</td>
        <td width="138" valign="top" style="text-align: left"> &nbsp;<span lang='bg'>Create your Flash ads here. Type the url, dimension and quality of your .swf file. </span>
                        &nbsp; </td>
        <td width="5" valign="top" style="text-align: left">&nbsp;</td>
        <td width="138" valign="top" style="text-align: left">&nbsp;Create your HTML ads here. Advertising link is HTML code(html lines or web
        page)</td>
        <td width="5" valign="top" style="text-align: left">&nbsp;</td>
        <td width="145" valign="top" style="text-align: left">&nbsp;If you want your
        ads to open in new window, Create your ads as pop-up or pop-under</td>
        <td width="13" valign="top">&nbsp;</td>
      </tr>
      <tr>
        <td width="5">&nbsp;</td>
        <td width="137"><a href="index.php?Act=add_text">
                      <img src='../merchants/images/grapgicb.gif' width='135' height='34' border='0'></a></td>
        <td width="5">&nbsp;</td>
        <td width="142"><a href="index.php?Act=add_banner">
                      <img src='../merchants/images/grapgicc.gif' width='135' height='34' border='0'></a></td>
        <td width="5">&nbsp;</td>
        <td width="138"> <a href="index.php?Act=add_flash">
                      <img src='../merchants/images/grapgicd.gif' width='135' height='34' border='0'></a></td>
        <td width="5">&nbsp;</td>
        <td width="138">
                  <b>
                      <a href="index.php?Act=add_html">
                      <img src='../merchants/images/grapgice.gif' width='135' height='34' border='0'></a></b></td>
        <td width="5">&nbsp;</td>
        <td width="145">
                  <a href="index.php?Act=add_popup">
                      <img src='../merchants/images/grapgicf.gif' width='135' height='34' border='0'></a></td>
        <td width="13">&nbsp;</td>
      </tr>
      <tr>
        <td width="738" class="tdhead" colspan="11">&nbsp;</td>
      </tr>
    </table>
    </center>
  </div>

<br/>
<form name='form1' method='post' action=''>
</div>