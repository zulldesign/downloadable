<?php	ob_start();

	include_once '../includes/constants.php';
	include_once '../includes/functions.php';
	include_once '../includes/allstripslashes.php';
	
	$partners=new partners;
	$partners->connection($host,$user,$pass,$db);
	
	$name=trim($nametxt);
	$$status=trim($status);
	///////////// remove an evemt

	$categorycompo=trim($categorycompo); 
	
	if ($categorycompo=="Choose a Category")
	{
		$msg = "select a Category to Delete!!";
		header("Location:index.php?Act=category&msg=$msg");
	}
	else {
		$test1	= "SELECT affiliate_category  FROM  partners_affiliate ".
				" WHERE affiliate_category ='".addslashes($categorycompo)."'"; 
				$test2="SELECT  merchant_category FROM partners_merchant ".
				" WHERE merchant_category ='".addslashes($categorycompo)."' ";
			
		$res1= mysql_query($test1) or die("cant exe 1");
		echo mysql_error();
		
		$res2=mysql_query($test2) or die("cant exe 2");
		echo mysql_error();  


		if(mysql_num_rows($res1)==0 and mysql_num_rows($res2)==0){
		
			$sql1	= "Delete from partners_category where cat_name='".addslashes($categorycompo)."'";
			$res1	= mysql_query($sql1) or die ("cant delete this category");
			
			$msg 	= "Category ".$categorycompo." Deleted !!";
			header("Location:index.php?Act=category&msg1=$msg");
			
			exit;
		}
		else{
			$msg =  "Can't Remove ... Members Exists on  ".$categorycompo;
			header("Location:index.php?Act=category&msg1=$msg");
		}
	}
?>