<?php
/************************************************************************/
/*     PROGRAMMER     :  SMA                                            */
/*     SCRIPT NAME    :  permission_denied.php                          */
/*     CREATED ON     :  14/JULY/2006                                   */

/*	 Page that displays Permission Denied message to Admin Users .		*/
/************************************************************************/
?>

<table align="center" cellpadding="0" cellspacing="0" class="tablebdr" width="100%" height="300">
	<tr>
		<td align="center" valign="middle">
			<b><font size="+2" color="#000000">Permission Denied.</font></b>
		</td>
	</tr>
</table>

