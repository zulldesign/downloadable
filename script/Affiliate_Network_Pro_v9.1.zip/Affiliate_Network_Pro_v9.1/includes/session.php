<?php
    session_start();
    session_register("CRMMERCHANT");
    session_register("ADMIN");
    session_register("ADMINNAME");
    session_register("MAIL");
    session_register("MERCHANT");
    session_register("AFFILIATE") ;
    session_register("HEADER") ;
    session_register("BODY") ;
    session_register("FOOTER") ;
    session_register("msg") ;
    session_register("res") ;
    session_register("SESSIONSTATUS");
    session_register("JOINSTATUS");
    session_register("MERCHANTID");
    session_register("AFFILIATEID") ;
    session_register("PROGRAMID") ;
    session_register("DES") ;
    session_register("LINKS") ;
    session_register("PGMID") ;
    session_register("MAILAMNT") ;
    session_register("MAILHEADER") ;
    session_register("MAILFOOTER") ;
    session_register("TRANS_MERCHANTID");

    session_register("BANNERCODE") ;
    session_register("VAR");

   session_register("SORTINGTABLE") ;
   session_register("MER_SORTINGTABLE") ;
   session_register("CAT_SORTING") ;
   session_register("LANGUAGE") ;
   session_register("MERCHANTNAME") ;
   session_register("PAYMODE") ;
   session_register("MERCHANTBALANCE");

   session_register("AFFILIATENAME") ;

   session_register("AFFILIATEBALANCE");
   
   session_register("ADMINLASTLOGGEDIP");
   session_register("USERRETRIEDCOUNT");
   session_register("ADMINUSERID");
   
   session_register("DEFAULTCURRENCYSYMBOL");
   
   session_register("AFF_ADDRESS");
   session_register("MER_ADDRESS");
   
   session_register("AFFILIATE_REFERER_ID");


   $USERCOOKIE_FOR_TRACKING = array();
  
	//to get all session variables
    foreach ($_SESSION as $key => $value)
    {
           $value=stripslashes(trim($value));
           $$key=$value;           
    }  
?>