<table cellpadding="0" cellspacing="0" width="95%" >
  <tr>
		<td width="100%" align="right">
		 [<a href="index.php?Act=daily"><?=$lang_home_daily?></a>]
		 [<a href="index.php?Act=forperiod"><?=$lang_home_forperiod?></a>]
		 [<a href="index.php?Act=TransReport"><?=$lang_home_transaction?></a>]
		 [<a href="index.php?Act=LinkReport"><?=$lang_home_links?></a>]
		 [<a href="index.php?Act=productReport"><?=$lang_pdt_report?></a>]
		 [<a href="index.php?Act=subid_report"><?=$lang_subid_report?></a>]	 
		 [<a href="index.php?Act=referral"><?=$lang_referral_report?></a>]
		 </td>
     </tr>
</table>