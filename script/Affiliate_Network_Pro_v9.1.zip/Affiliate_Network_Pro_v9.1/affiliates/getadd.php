        <p></p>
<table cellpadding="0" cellspacing="0" width="750" align="center">
	<tr>
		<td align="right"><a href="index.php?Act=sub_id_list">&laquo;<?=$lang_home_manage_subid?>&raquo;</a></td>
	</tr>
</table><br/>
          <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse; text-align: center"  align="center" width="750" id="AutoNumber3" class="tablebdr">
      <tr>
        <td width="4" class="tdhead">&nbsp;</td>
        <td width="120" class="tdhead"><b>
                <?=$lang_home_text?></b></td>
        <td width="5">&nbsp;</td>
        <td width="120" class="tdhead">
                <b><?=$lang_home_banner?></b></td>
        <td width="4">&nbsp;</td>
       <td width="120" class="tdhead"><b>
                <?=$lang_home_flash?></b></td>
        <td width="5">&nbsp;</td>
        <td width="120" class="tdhead"><b><?=$lang_home_html?></b></td>
        <td width="4">&nbsp;</td>
        <td width="120" class="tdhead"><b>
  <?=$lang_home_popup?></b></td>
	  <td width="4" valign="top">&nbsp;</td>
        <td width="124" class="tdhead"><b><?=$lang_home_texttemplate?></b></td>
      </tr>
      <tr>
        <td width="4" valign="top">&nbsp;</td>
        <td width="120" valign="top" class="grid1">
        <?=$lang_text_help?><br/>&nbsp;</td>
        <td width="5" valign="top" style="text-align: left">&nbsp;</td>
        <td width="120" valign="top" class="grid1">
        <?=$lang_banner_help?><br/>&nbsp;</td>
        <td width="4" valign="top" style="text-align: left">&nbsp;</td>
       <td width="120" valign="top" class="grid1">
        <?=$lang_flash_help?></td>
        <td width="5" valign="top" style="text-align: left">&nbsp;</td>
        <td width="120" valign="top" class="grid1">
        <?=$lang_html_help?></td>
        <td width="4" valign="top" style="text-align: left">&nbsp;</td>
        <td width="120" valign="top" class="grid1">
        &nbsp;<?=$lang_popup_help?></td>
        <td width="4" valign="top">&nbsp;</td>
		<td width="124" valign="top" class="grid1"><?=$laddban_TemplateAdtext?></td>
      </tr>
	  
      <tr bgcolor="#DEE5EB">
        <td width="4">&nbsp;</td>
        <td width="120" ><a href="index.php?Act=gettext">
                      <img src='images/text.jpg'  border='0'  alt=""/></a></td>
        <td width="5">&nbsp;</td>
        <td width="120"><a href="index.php?Act=getbanner">
                      <img src='images/graphic.jpg'  border='0'  alt=""/></a></td>
        <td width="4">&nbsp;</td>
      <td width="120"> <a href="index.php?Act=getflash">
                      <img src='images/flash.jpg'  border='0'  alt=""/></a></td>
        <td width="5">&nbsp;</td>
        <td width="120">
                      <a href="index.php?Act=gethtml">
                      <img src='images/html.jpg'  border='0'  alt=""/></a></td>
        <td width="4">&nbsp;</td>
        <td width="120">
                  <a href="index.php?Act=getpopup">
                      <img src='images/pop.jpg'  border='0'  alt=""/></a></td>
        <td width="4">&nbsp;</td>
		<td width="124">&nbsp;<a href="index.php?Act=gettextnew">
                      <img src='images/temp_text.jpg'  border='0'  alt=""/></a></td>
      </tr>
      <!--<tr>
        <td class="tdhead" colspan="12">&nbsp;</td>
      </tr>-->
    </table><br />