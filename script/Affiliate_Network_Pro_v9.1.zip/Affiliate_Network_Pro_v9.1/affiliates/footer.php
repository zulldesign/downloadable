	<table cellpadding="0" cellspacing="0" width="100%" border="0">
			<tr>
			<td height="30" align="center">
			<a href="index.php?Act=Home" class="link-01" ><?=$menu_home?></a> | 
			<a href="index.php?Act=Account"><?=$menu_accounts?></a> | 
			<a href="index.php?Act=Affiliates&amp;joinstatus=All"><?=$menu_programs?></a> | 
			<a href="index.php?Act=rotator"><?=$menu_rotator?></a> | 
			<a href="index.php?Act=Getlinks"><?=$menu_getlinks?></a> | 
			<a href="index.php?Act=daily"><?=$menu_reports?></a> | 
			<a href="../affiliate_quit.php"><?=$menu_quit?></a>
			</td>
		</tr>
		<tr>
			<td height="25" align="center">Copyright 2004 &copy; AlstraSoft Affiliate Network Pro. All Rights Reserved.</td>
		</tr>
	</table>