<?
$site_title							= "Affiliate Network Pro";
$lang_add_success_msg               = "Your Request has been sent. <br/>This amount will be deposited to your account after you pay.";
$lang_Amount                         = "Amount";
$lang_merPay						 = "Merchant Payment";
$lang_NPcaption4					 = "Note";
$lang_NPcaption3					 = " Please deposit money so that you can access your account";
$lang_NPcaption2					 = "Your current balance is ";
$lang_NPcaption 					 = " You haven't done your payment so far. Please pay so that you can get our service. ";
$lang_NPcaption1					 = " Your Acccount Status has been changed to money empty state, since your current account balance has gone down. ";
$lang_merchant_currency				 = "Currency";
$pay_fail                            = "Payment Failed. Please try again !!!!!";
$lang_Status                         = "Status";
$lang_Payment                        = "Payment";
$lang_Email                          = "Email";
$getpass                             = "Get Your Password";
//$test                                = "test";
$lang_Home                           =  "Home";
$lang_welcome                        =  "Welcome !";
$lang_pay_msg                        = " You have No Pending Payments...Please Login.";
$lang_Merchants                      = "Merchants";
$lang_Affiliates                     = "Affiliates";
$lang_Directory                      = "Directory";
$lang_Login                          = "Login";
$lang_About                          = "About us";
$lang_Contact	                     = "Contact us";
$lang_Choose                         = "Choose";
$lang_Username                       = "Username";
$lang_Password                       = "Password";
$lang_Enter                          = "Enter";
$lang_Forgot                         = "Forgot your Password ";
$lang_iPartnersmanager               = "Affiliate Network Pro is compatible with most shopping carts, signup forms and online ordering systems. Affiliate Network Pro is a 100% web-based affiliate tracking software solution.";
$lang_REGISTER                       = "REGISTER NOW";
$lang_MERCHANTS                      = "MERCHANTS";
$lang_AFFILIATES                     = "AFFILIATES";
$lang_NEWm                           = "NEW MERCHANT";
$lang_NEWa                           = "NEW AFFILIATE";
$lang_Turn                           = "Turn your website's web traffic into a commission check by signing up as an affiliate.";
$lang_Increase                       = "Increase website visits and market your products and services through our easy-to-use, effective advertising solution.";
$lang_FEATURES                       = "FEATURES";


$featurelist                         =" Categorization of Affiliates and Merchants.";
$featurelist13                       =" Real Time Reporting. ";
$featurelist2                        =" Web Based Application Console. ";
$featurelist3                        =" Support Two-Tire Commission.";
$featurelist4                        =" More profitability. ";
$featurelist5                        =" Flexibility. ";
$featurelist6                        =" Better Support. ";
$featurelist7                        =" Friendliness. ";
$featurelist8                        =" Trust. ";
$featurelist9                        =" Effectiveness. ";
$featurelist10                       =" Fraud Prevention. ";
$featurelist11                       =" Automated E-mail Message. ";
$featurelist12                       =" Auto-Generation Banner Rotators. ";

$featurelistnew                      = " Real Time Reporting. ";
$featurelistnew1                     = " More profitability. ";
$featurelistnew2                     = " Flexibility. ";
$featurelistnew3                     = " Better Support.";
$featurelistnew4                     = " Friendliness. ";
$featurelistnew5                     = " Trust.";
$featurelistnew6                     = " Effectiveness.";
$featurelistnew7                     = " Fraud Prevention.";
$featurelistnew8                     = " Automated E-mail Message. ";

$lang_When                           = "When you join with Affiliate Network Pro, you are associating yourself with the best in the industry. We have simple, easy-to-use online account management tools.";
$lang_Our                            = " numer one goal is to provide the best customer service possible, and we are living up to that goal. Make your life easier and simpler: join Affiliate Network Pro        ";
$lang_BENEFITS                       = "BENEFITS";


$benefitlist1                        = "Increased traffic and sales   ";
$benefitlist2                        = "Access to a pool of quality Members";
$benefitlist3                        = "Easy Web-based access to the reports and administration ";
$benefitlist4                        = "24 hour turn-around customer service";
$benefitlist5                        = "Gain internet real estate for your product and services ";
$benefitlist6                        = "Low customer acquisition costs   ";
$benefitlist7                        = "An experienced team managing their affiliate program  ";
$benefitlist8                        = "Ability to grow your current affiliate base  ";
$benefitlist9                        = "Ability to choose the service that best suits your business needs  ";

$lang_reg                            =  "When you sign up as an affiliate, you trust the best in the industry. We have the best systems and the best staff to support your needs. Our systems are always being updated to bring you better service, and our staff has continual training. Save time, money, and sanity: sign up with Affiliate Network Pro. You will not regret it.";
$afffeaturelist1                     =  "Earn money through your website by redirecting visitors to merchant site";
$afffeaturelist2                     =  "Access to a pool of quality Members";
$afffeaturelist3                     =  " Easy Web-based access to the reports and administration";
$afffeaturelist4                     =  " 24 hour turn-around customer service";
$afffeaturelist5                     =  " Opportunity to earn more money through secondtire commissions";
$afffeaturelist6                     =  " An experienced team managing their affiliate program";
$afffeaturelist7                     =  " Ability to grow your current merchant base";
$afffeaturelist8                     =  " Ability to choose the service that best suits your business";

$lang_Increase                       = "Increase website visits and market your products and services through our easy-to-use, effective advertising solution.";
$lang_turnyour                       = "Turn your website's web traffic into a commission check by signing up as an affiliate.";
$lang_aboutus                        = "ABOUT US";
$lang_contactus                      = "CONTACT US";
$lang_cat                            = "All Categories";
$lang_newpgm                         = "Newest Programs";
$lang_merchant                       = "Merchant";
$lang_pgm                            = "Program";
$lang_click                          = "Click";
$lang_sale                           = "Sale";
$lang_lead                           = "Lead";
$lang_action                         = "Action";
$lang_category                       = "----Select a Category----";
$lang_firstname                      = "First Name";
$lang_Last                           = "Last Name";
$lang_caption                        = "Turn your website's web traffic as a publisher.";
$lang_copyright                      = "Copyright 2004 &copy; Affiliate Network Pro";
$lang_language						 = "Language";

$reqd                                = "Required Fields";
$lang_AffiliateRegistration          = "Affiliate Registration";
$MerchantRegistration                = "Merchant Registration";
$lang_EmailId                        = "Email Address";
$lang_Password                       = "Password";
$lang_MerchantContactInfo            = "Merchant Contact Info";
$lang_FirstName                      = "First Name";
$lang_LastName                       =  "Last Name";
$lang_Company                        =  "Company";
$lang_URL                            =  "URL";
$lang_Address                        =  "Address ";
$lang_Category                       =  "Category";
$lang_Phone                          =  "Phone";
$lang_Fax                            =  "Fax";
$lang_Type                           =   "Type";
$lang_City                           =   "City";
$lang_Country                        =   "Country";
$lang_Edit                           =   "Edit";
$lang_SelectaCountry                 =   "-----Select a Country-----";
$selectacategory                     =   "-----select a category-----";
$selectatype                         =   "-----select a type-----";
$lang_success_message                =   "Merchant Contact Info Updated Successfully.";
$lang_invalid                        =   "Invalid Entry. Please fill in all required fields ";
$lang_Advance                        =   "Advance";
$lang_Normal                         =   "Normal";
$lang_blank                          = "Don't leave any manadatory fields blank";
$lang_emailerr                       = "Please enter a valid email id";
$lang_email1                         = "Email Already Exists";
$lang_success                        = "You have registered successfully. Your password will be sent through email  ";
$lang_success_pay	                 = " Your Payment has been processed successfully!! ";
$parentselect                        = "---Introduced Affiliate----";
$lang_ParentID                       = "Referrer";
$lang_Name                           = "Name";
$lang_Location                       = "Location";
$lang_payapalemail                   = "Email";
$lang_stormemail                     = "Email";
$lang_payeename                      = "Payee Name";
$lang_acno                           = "Account No";
$lang_productid                      = "Product Id";
$lang_checkoutid                     = "Checkout Id";
$lang_version                        = "Version";
$lang_delimdata                      = "DelimData";
$lang_relayresponse                  = "RelayResponse";
$lang_login                          = "Login";
$lang_trankey                        = "Trankey";
$lang_cctype                         = "cctype";
$lang_Paypal                         = "PAYPAL";
$lang_Stormpay                       = "STORMPAY";
$lang_2Checkout                      = "2CHECKOUT";
$lang_eGold                          = "EGOLD";
$lang_Authorize                      = "AUTHORIZE.NET";
$lang_chkerr                         = "Please Enter 2Checkout Details";
$lang_autherr                        = "Please Enter Authorize.net Details";
$lang_egolderr                       = "Please Enter EGold Details";
$lang_stormerr                       = "Please Enter Valid Storm Pay Email";
$lang_payerr                         = "Please Enter Valid Paypal Email";
$lang_PaymentGateway                 = "Mode of Payment";
$lang_perror                         = "Sorry Payment Error";
$lang_notauth                        = "Not Authorized!";
$lang_notauth1                       = "Not Approved!";
$lang_state                          = "State";
$lang_zip                            = "Zip Code";
$lang_timezone                       = "TimeZone";
$lang_terms_condn                    = "Terms &amp; Conditions";
$lang_terms                          = "Click here to indicate that you have read and agree to the User Agreement and Privacy Policy.";
$lang_termserr                       = "Please Agree to the terms and conditions";

$lang_neteller_caption		    	= "NETeller";
$lang_neteller_email                = "Email";
$lang_neteller_accnt                = "Account Number";

$lang_check_caption					= "Check By Mail";
$lang_check_payee                   = "Payee Name";
$lang_check_curr                    = "Currency";
$lang_checkerr                      = "Please Enter All Details";

$lang_wire_caption					= "Wire Transfer";
$lang_wire_AccountName              = "Account Name";
$lang_wire_AccountNumber            = "Account Number";
$lang_wire_BankName                 = "Bank Name";
$lang_wire_BankAddress              = "Bank Address ";
$lang_wire_BankCity                 = "Bank City ";
$lang_wire_BankState                = "Bank State/Province";
$lang_wire_BankZip         			= "Bank Postcode/Zip";
$lang_wire_BankCountry              = "Bank Country";
$lang_wire_BankAddressNumber        = "Bank Address Number";
$lang_wire_Nominate					= "Preferred currency";
$allreqd                            = "All Fields Are Required";
$lang_netellererr                   = "Please Enter a valid email address";
$lang_dontleave						= "Please Don't Leave Any Fields Blank";
$lang_emailmsg						= "Please Enter A Valid Email";
$lang_contactmsg					= "Your Message has been sent successfully";
$lang_taxId                         = "Tax Id";

//added by jincy
$regval_msg				= "Not Authorized!!";

$aff_quit				= "Affiliate Session closed!";

$regbank_true			= "True";
$regbank_false			= "False";
$regbank_authcap		= "AUTH_CAPTURE";
$regbank_authonly		= "AUTH_ONLY";
$regbank_caponly		= "CAPTURE_ONLY";
$regbank_credit			= "CREDIT";
$regbank_void			= "VOID";
$regbank_prior			= "PRIOR_AUTH_CAPTURE";

$paymoney_but			= "Pay Now";

$directory_help_join	= "Join";

$merreg_method			= "Method";
$merreg_pay				= "Pay Per Invoice";

$forgotpass_title		= "Affiliate Network Pro - Forgot Password";
$forgotpass				= "Forgot Password";
$forgotpass_choose		= "Choose";
$forgotpass_merchant	= "Merchants";
$forgotpass_affiliate	= "Affiliates";
$forgotpass_email		= "Email";
$forgotpass_submit		= "Submit";

$merpay_register		= "Register";

$merchant_quit			= "Merchant Session closed!";

$contact_ussend			= "Send";


/// Additions for ANP Phase 4 Modifications

	$msg_retrylimit 	= "You have completed the login retry limit.  ";
	$msg_delayseconds	= "You can login using the correct username and password only after ";
	$msg_seconds		= " seconds";
	$logincompleted		= ".  You have completed ";
	$loginsoutof		= " logins out of ";
	$allowedlogins		= " allowed logins";
	
//added on 20-JUNE-2006
		$recur_commission_head		= "Recurring Sale Commission";
		$recur_sale_head			= "Recur Sale Commission by ";
		$recur_percent_month_head	= " percentage.&nbsp;&nbsp;&nbsp;&nbsp;Recur Every ";
		$err_enterRecurPercent		= "Enter a value for the percentage of Recurring Amount";
		$recur_months_head			= "Month";
		$recur_no_msg				= "Sale Commission is not Recurring";

//added on 3-July-2006
		$err1001		= "Not Authorized!";
		$err1002		= "Enter valid Username and Password";
		$err1000		= "Invalid Username";
		$err1003		= "Not Approved!";
		$err1004		= $msg_retrylimit.$msg_delayseconds.$fraudsettings_login_delay.$msg_seconds;
		$err1005		= $err1001.$logincompleted.$_SESSION['USERRETRIEDCOUNT'].$loginsoutof.$fraudsettings_login_retry.$allowedlogins;
		 
//added on 10-JULY-2006 for Help on Graphs
		$lang_help_close	= "Close";

		$lang_ReturnDays	= "Return Day Analysis";
		$lang_RDA_help1		= "This graph displays the ratio of the duration between the sale completed by the Affiliate after the first click";
		$lang_RDA_help2		= "The Sales completed on same day after click, within 15 days, within 1 month, within 2 months and after 2 months are displayed by sections in different colors";
		$lang_RDA_help3		= "Select a Merchant for whom the Graph is to be displayed";
		$lang_RDA_help4		= "The list of all the Affiliates under the Merchant is displayed";
		$lang_RDA_help5		= "The Return Day Analysis Graph for All the Affiliates of the Merchant is displayed initially";
		$lang_RDA_help6		= "The graph for the individual Affiliates can be viewed by selecting Affiliates from the list";
		
		$lang_AffiliateatGlance	= "Affiliate At a Glance";
		$lang_AAG_help1			= "This graph displays the ratio of clicks and sales made by the Affiliates of a Merchant";
		$lang_AAG_help2			= "The graph gives an overview of the performance of the Affiliates at a Glance";
		$lang_AAG_help3			= "Select a Merchant for whom the Graph is to be displayed";
		$lang_AAG_help4			= "The list of all the Programs created by the Merchant is listed";
		$lang_AAG_help5			= "The Affiliate At a Glance report for All the Programs of the Merchant is displayed initially";
		$lang_AAG_help6			= "The rows in the Graph represents each Affiliate joined for the Merchant's Program";
		$lang_AAG_help7			= "The left side of the Graph represents the performance of the Affiliates based on Clicks and the right side represents Sales";
		$lang_AAG_help8			= "The name of the Affiliate is written on the left most end of each row";
		$lang_AAG_help9			= "The number written on each row represents the click or the sale made by the corresponding Affiliate";
		$lang_AAG_help10		= "The Graph for individual Programs can be viewed by selecting the Program from the list Provided";
		$lang_AAG_help11		= "The graph can be displayed for a selected period by selecting a from date and to date and then clicking the View button";
		
		$lang_Distribution	= "Distribution Report";
		$lang_DR_help1		= "This graph displays the ratio of the performance of a Group of Affiliates";
		$lang_DR_help2		= "The Affiliates 1-10, 11-20, 21-50, 50-75 and Above 75 are grouped";
		$lang_DR_help3		= "Select a Merchant for whom the graph is to be displayed";
		$lang_DR_help4		= "The Distribution Report for clicks is displayed initially";
		$lang_DR_help5		= "The Graph for Sales or Commission can be displayed by selecting the appropriate Action from the list";
		$lang_DR_help6		= "The ratio of the Performance of the group of Affiliates can be identified by the specific color defined for the Group";
		
		$lang_bubblePlot	= "Bubble Plot";
		$lang_BP_help1		= "This graph displays the ratio of the clicks or sales and the Commission earned by the Affiliates of a Merchant";
		$lang_BP_help2		= "Select a Merchant for whom the Graph is to be displayed";
		$lang_BP_help3		= "The Action selected(Clicks or Sales) is represented along the X-axis";
		$lang_BP_help4		= "The Affiliates of the Merchant is displayed along the Y-axis";
		$lang_BP_help5		= "The size or the diameter of the Bubble in the graph denotes the commission earned by the corresponding Affiliate";
		$lang_BP_help6		= "The bubbles for each affiliate will be positioned along the X-axis according to the count click or the sale";
		$lang_BP_help7		= "Each Row in the Graph represents the Affiliates of the Merchant"; 
		$lang_BP_help8		= "The name of the Company of the Affiliates is written along the left side of each row";
		
// Added on 17-JULY-2006 for Print Report Section
		$lang_print_report		= "Print Report";

		$lang_recur_transaction	= "Recurring Transactions";
		$recur_affiliate		= "Affiliate";
		$recur_aff_company		= "Company";
		$recur_aff_url			= "URL";
		$recur_Date				= "Date";
		$recur_OrderId			= "Order Id";
		$recur_Commission		= "Commission";
		$recur_subsaleComm		= "Subsale Commission";
		$recur_Action			= "Action";
		$recur_commStatus		= "Commission Status";
		$recur_saleAmount		= "Sale Amount";
		$recur_total_comm		= "Total Commission";
		$recuring_every			= "Recurring Every";
		$recur_total_sub_comm	= "Total Subsale Commission";
		$recur_Status			= "Status";
		
		$lang_report_Recurring	= "Recurring Commission";
		$lang_recur_approved	= "Approved Recurring Commission";
		$lang_recur_pending		= "Pending Recurring Commission";
		$recur_commission_details	= "Recurring Commission Details";
		$recur_trans_details	= "Recurring Transaction Details";
		$recur_balance			= "Balance Commission";
		$recur_bal_subsale		= "Balance Subsale Commission";
		$recur_nextdate			= "Next Recurring Payment On";
		
		$trans_type 			= "Type";
		$trans_date				= "Date";
		$trans_status			= "Status";
		$trans_orderId			= "OrderId";
		$trans_comm				= "Commission ( Affiliate + Admin ) ";
		$trans_affiliate		= "Affiliate";
		$trans_merchant			= "Merchant";
		$trans_commission		= "Commission";
		$trans_report_head		= "Transaction Report";
		
//Daily Report
//--------------------------------------forperiod-------------------------------------------------//
		$lang_report_daily				= "Daily Report";
		$lang_report_stat				="Statistics For Custom Period";
		$lang_report_forperiod			="For Period";
		$lang_report_from				="From";
		$lang_report_to 				="To";
		$lang_report_view				="View";
		$lang_report_err				="Please Enter Valid Date" ;
		
		$lang_report_SearchProgram		="Search Programs";
		$lang_report_AllProgram			="All Program";
		$lang_report_allmerchant		= "All Merchants";
		$lang_report_allaffiliate		= "All Affiliates";
		$lang_report_AllAffil			="Total Affiliates";
		$lang_report_searchaff			="Search Affiliate";

//--------------------------------------transaction-------------------------------------------------//
		$lang_report_commission			="Commission";
		$lang_report_transaction		="Transaction";
		$lang_report_number				= "Number";
		$lang_impression				= "Impression";
		$lang_report_subsale  			="Sub Sale";     
		
		$lang_report_date				="Date";
		$lang_report_status				="Status";
		$lang_report_type 				="Type";
		$lang_report_merchant			="Merchant";
		$lang_report_affiliate			="Affiliate";
		
		$lang_report_affiliate_head		= "Affiliate Report for Custom Period ";
		$lang_report_approved_amt		= "Approved Amount";
		$lang_report_pending_amt		= "Pending Amount";
		$lang_report_reversed_amt		= "Reversed Amount";
		$lang_report_subid				= "Sub-ID :- ";
		$lang_report_count				= "Count";
		$lang_report_linkname			= "Link Name";
		
//Product Report Details		
		$laddban_Flash                   = "Flash";
		$lang_product_Type               = "Type";
		$lang_product_Product            = "Product";
		$lang_product_Affiliate          = "Affiliate";
		$lang_product_Commission         = "Commission";
		$lang_product_Date               = "Date";
		$lang_product_Status             = "Status";
		$lang_product_Merchant			 = "Merchant";
	
	$lang_referral_report    	=   "Referral Commission";
	$lang_referral_downlines   	=   "Affiliates";
	$lang_referral_salesMade   	=   "Referral Sales";
	$lang_total_commission    	=   "Total Commission";


# Multiple COmmission Structure
	$lang_commission_structure	= "Commission Structure ";
	$lang_value_above			= "Above";
	$lang_viewCommision 		= "View Commission";
	$lang_value_Commision		= "Commision";
		
?>