<?
//added on 3-July-2006 for Admin Errors and Messages
	$ad1000			= "Admin session is already open from ".$_SESSION['ADMINLASTLOGGEDIP']."<br/>Log off from there or Try after a while	";
	$ad1001			= "Not Authorized!!";
	$ad1002			= "Enter valid Username and Password";
	$ad1003			= "Admin Session closed!";
	
	$adopt2000		= "Error in data:Invalid Mail Format";
	$adopt2001		= "Admin mail changed";
	$adopt2002		= "Unknown Error! Please Try Again";
	$adopt2003		= "Error in data:Invalid Login";
	$adopt2004		= "Admin login changed";
	$adopt2005		= "Error in data:Invalid Passwords";
	$adopt2006		= "Error in data: New Passwords Mismatch";
	$adopt2007		= "Error in data: Current Password Mismatch";
	$adopt2008		= "Admin Password changed";
	$adopt2009		= "Page Title changed";
	$adopt2010		= "Error: Invalid entry";
	$adopt2011		= "Lines per page changed";
	$adopt2012		= "Enter a Numeric Value";
	$adopt2013		= "Error Page Settings changed";
	$adopt2014		= "Email Address already exists";
	$adopt2015		= "User Name already exists";
	


?>