
 <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                  <tr>
                    <td colspan="2" valign="top" class="box-01">
					<table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td height="41" class="welcome"><?=$lang_welcome?></td>
                      </tr>
                      <tr>
                        <td class="text-01"><div align="justify"><?=$lang_iPartnersmanager?></div></td>
                      </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td colspan="2" height="5"></td>
                  </tr>
                  <tr>
                    <td width="50%" valign="top">
					<table width="349" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                           <!-- <td><img src="images/affiliate-top.jpg" width="349" height="27" /></td>-->
							 <td class="affiliates-top"><div class="box-heading">&nbsp;&nbsp;&nbsp;AFFILIATES</div></td>
                          </tr>
                          <tr>
                            <td class="affiliate-content-bg">
							<table width="96%" border="0" align="center" cellpadding="0" cellspacing="0">
                              <tr>
                                <td colspan="2" align="center">&nbsp;</td>
                                </tr>
                              <tr>
                                <td width="38%" valign="top" align="center"><div><img src="images/affiliate-img.jpg" width="115" height="84" /></div>
								
								  <div>&nbsp;</div>
								  <div><a href="index.php?Act=affil_regi"><img src="images/affiliate-reg-btn.jpg" width="116" height="24" border="0" /></a></div>								  </td>
                                <td width="62%" valign="top" class="text-02"><?=$lang_Turn?></td>
                              </tr>
                              <tr>
                                <td colspan="2" align="center" valign="top">&nbsp;</td>
                                </tr>
                            </table></td>
                          </tr>
                          <tr>
                            <td><img src="images/affiliate-bottom.jpg" width="349" height="10" /></td>
                          </tr>
                        </table></td>
                      </tr>
                      
                      <tr>
                        <td height="5"></td>
                      </tr>
                      <tr>
                        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <!--<td><img src="images/merchants-top.jpg" width="348" height="26" /></td>-->
							 <td class="merchants-top"><div class="box-heading">&nbsp;&nbsp;&nbsp;MERCHANTS</div></td>
                          </tr>
                          <tr>
                            <td class="merchants-content-bg">
							<table width="96%" border="0" align="center" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td colspan="2" align="center">&nbsp;</td>
                                </tr>
                                <tr>
                                  <td width="38%" valign="top" align="center"><div><img src="images/merchants-img.jpg" width="117" height="86" /></div>
                                      <div>&nbsp;</div>
                                    <div><a href="index.php?Act=register"><img src="images/merchants-reg-btn.jpg" border="0" /></a></div></td>
                                  <td width="62%" valign="top" class="text-02"><div align="justify">
                          <?=$lang_Increase?>
                        </div></td>
                                </tr>
                                <tr>
                                  <td height="23" colspan="2" align="center" valign="top">&nbsp;</td>
                                </tr>
                            </table></td>
                          </tr>
                          <tr>
                            <td><img src="images/merchants-bottom.jpg" width="348" height="9" /></td>
                          </tr>
                        </table></td>
                      </tr>
                    </table></td>
                    <td width="50%" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>

	    <td class="features-top"><div class="box-heading">&nbsp;&nbsp;&nbsp;FEATURES</div></td>

  </tr>
  <tr>
    <td class="fetures-content-bg"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td colspan="2" align="center">&nbsp;</td>
        </tr>
      <tr>
        <td width="15%" height="25" align="center"><img src="images/bullet.jpg" width="8" height="10" /></td>
        <td width="85%" align="left" class="text-02"><?=$featurelist?></td>
      </tr>
      <tr>
        <td height="25" align="center"><img src="images/bullet.jpg" width="8" height="10" /></td>
        <td align="left" class="text-02"><?=$featurelist13?></td>
      </tr>
      <tr>
        <td height="25" align="center"><img src="images/bullet.jpg" width="8" height="10" /></td>
        <td align="left" class="text-02"><?=$featurelist2?></td>
      </tr>
      <tr>
        <td height="25" align="center"><img src="images/bullet.jpg" width="8" height="10" /></td>
        <td align="left" class="text-02"><?=$featurelist3?>.</td>
      </tr>
      <tr>
        <td height="25" align="center"><img src="images/bullet.jpg" width="8" height="10" /></td>
        <td align="left" class="text-02"><?=$featurelist4?></td>
      </tr>
      <tr>
        <td height="25" align="center"><img src="images/bullet.jpg" width="8" height="10" /></td>
        <td align="left" class="text-02"><?=$featurelist5?></td>
      </tr>
      <tr>
        <td height="25" align="center"><img src="images/bullet.jpg" width="8" height="10" /></td>
        <td align="left" class="text-02"><?=$featurelist6?></td>
      </tr>
      <tr>
        <td height="25" align="center"><img src="images/bullet.jpg" width="8" height="10" /></td>
        <td align="left" class="text-02"><?=$featurelist7?></td>
      </tr>
      <tr>
        <td height="25" align="center"><img src="images/bullet.jpg" width="8" height="10" /></td>
        <td align="left" class="text-02"><?=$featurelist8?></td>
      </tr>
      <tr>
        <td height="25" align="center"><img src="images/bullet.jpg" width="8" height="10" /></td>
        <td align="left" class="text-02"><?=$featurelist9?></td>
      </tr>
      <tr>
        <td height="25" align="center"><img src="images/bullet.jpg" width="8" height="10" /></td>
        <td align="left" class="text-02"><?=$featurelist10?></td>
      </tr>
      <tr>
        <td height="25" align="center"><img src="images/bullet.jpg" width="8" height="10" /></td>
        <td align="left" class="text-02"><?=$featurelist11?></td>
      </tr>
      <tr>
        <td height="25" align="center"><img src="images/bullet.jpg" width="8" height="10" /></td>
        <td align="left" class="text-02"><?=$featurelist12?></td>
      </tr>
      <tr>
        <td colspan="2" align="center">&nbsp;</td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td><img src="images/features-bottom.jpg" width="341" height="9" /></td>
  </tr>
</table></td>
                  </tr>
                </table>
