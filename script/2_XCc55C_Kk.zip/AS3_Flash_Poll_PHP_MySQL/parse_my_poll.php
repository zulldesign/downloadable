<?php
/* 
::::::::::Script Written By: Adam Khoury @ www.developphp.com:::::::::::::
:::::::::If you find www.developphp.com tutorials helpful or handy:::::::::::::
:::::::::::please link to it wherever possible to help others find it::::::::::::::::
*/
// ---------------------------------------- Section 1 -----------------------------------------------
//  IMPORTANT!!!! Connect to MySQL database here(put your connection data here)
mysql_connect("Host_Name","MySQL_UserName","Password") or die (mysql_error());
mysql_select_db("Database_Name") or die (mysql_error());

// When Flash requests the totals initially we run this code
if ($_POST['myRequest'] == "load_numbers") {
	
	// Query the totals from the database
    $sql1 = mysql_query("SELECT id FROM votingPoll WHERE choice='1'"); 
    $choice1Count = mysql_num_rows($sql1); 
    $sql2 = mysql_query("SELECT id FROM votingPoll WHERE choice='2'"); 
    $choice2Count = mysql_num_rows($sql2); 
    $sql3 = mysql_query("SELECT id FROM votingPoll WHERE choice='3'"); 
    $choice3Count = mysql_num_rows($sql3); 

    echo "choice1Count=$choice1Count";
    echo "&choice2Count=$choice2Count";
    echo "&choice3Count=$choice3Count";

}
// ---------------------------------------- Section 2 -----------------------------------------------
// IF POSTING A USER'S CHOICE
if ($_POST['myRequest'] == "store_choice") {
	
    //Obtain user IP address 
    $ip = $_SERVER['REMOTE_ADDR'];
    // Create local variable from the Flash ActionScript posted variable
    $userChoice   = $_POST['userChoice'];
    $sql = mysql_query("SELECT id FROM votingPoll WHERE ipaddress='$ip'");
    $rowCount = mysql_num_rows($sql);
    if ($rowCount == 1) {
		
		$my_msg = "You have already voted in this poll.";
		print "return_msg=$my_msg";
		
    } else {
		
		$sql_insert = mysql_query("INSERT INTO votingPoll (choice, ipaddress) VALUES('$userChoice','$ip')")  or die (mysql_error());
		$sql1 = mysql_query("SELECT * FROM votingPoll WHERE choice='1'");
		$choice1Count = mysql_num_rows($sql1);
		$sql2 = mysql_query("SELECT * FROM votingPoll WHERE choice='2'");
		$choice2Count = mysql_num_rows($sql2);
		$sql3 = mysql_query("SELECT * FROM votingPoll WHERE choice='3'");
		$choice3Count = mysql_num_rows($sql3);
		$my_msg = "Thanks for voting!";
        echo "return_msg=$my_msg";
        echo "&choice1Count=$choice1Count";
		echo "&choice2Count=$choice2Count";
		echo "&choice3Count=$choice3Count";
    }
}
?>