<?php
/* 
Created By Adam Khoury @ www.delopphp.com
-----------------------May 2009-----------------------
This file is executed from the server and will create
the two tables needed for the system to operate
-----------------------May 2009-----------------------
*/
// connect to your MySQL database here using the 
// script sitting in the same folder as this one
include_once "connect_to_mysql.php";
// Tell ourselves on screen if we have connected
print "Success in database CONNECTION.....<br /><br />";
// Create the admin table
$createAdminTable = "CREATE TABLE cms_admin (
id int(11) NOT NULL auto_increment,
username varchar(255) NOT NULL,
password varchar(255) NOT NULL,
last_log_date date NOT NULL default '0000-00-00',
account_type enum('a','b','c') NOT NULL default 'a',
PRIMARY KEY (id)
) ";
// Create the page content table
$createContentTable = "CREATE TABLE cms_content (
id int(11) NOT NULL auto_increment,
home_body text NULL,
about_body text NULL,
PRIMARY KEY (id)
) ";
//////////////////////////////////////////////////////////////////////////////////////////////////
if (mysql_query($createAdminTable)){
	$sql = mysql_query("INSERT INTO cms_admin (username, password, last_log_date, account_type) 
									   VALUES('admin','password', now(),'a')") or die (mysql_error());
	
    print "Success in ADMIN TABLE creation!......<br /><br />";
	
} else {
    print "No Admin Table created. You have problems in the system already, backtrack and debug!";
    exit(); // exit the script so we can debug and try again
}
//////////////////////////////////////////////////////////////////////////////////////////////////
if (mysql_query($createContentTable)){
	$sql = mysql_query("INSERT INTO cms_content (home_body, about_body) 
									   VALUES('Welcome to the homepage','This is the about me page text.')") or die (mysql_error());
	
    print "Success in CONTENT TABLE creation!......<br /><br />";

} else {
	
    print "No Content Table created. You have problems in the system already, backtrack and debug!";
    exit(); // exit the script so we can debug and try again
}
//////////////////////////////////////////////////////////////////////////////////////////////////
// Print a success message now that both tables are created with no errors
print "<br />That completes the tables setup, now delete the file <br />
named 'create_Tables.php' and you are ready to move on. Let us go!";
?>