<?php
// connect to your MySQL database here
include_once "connect_to_mysql.php";

//////////////////////////////////////////////// Log User In ///////////////////////////////////////////////////////////////////
if ($_POST['sendRequest'] == "log_user_in") {

     $username = $_POST['username'];
     $password = $_POST['password'];
     $sql = mysql_query("SELECT * FROM cms_admin WHERE username='$username' AND password='$password' AND account_type='a'"); 
     $login_check = mysql_num_rows($sql);
     if($login_check > 0){ 
           print "return_msg=all_good";
     } else {
	       print "return_msg=no_good";
	 }
}
//////////////////////////////////////////////// Gather Home Page Text ///////////////////////////////////////////////////////////////////
if ($_POST['sendRequest'] == "get_home_text") {

    $sql = mysql_query("SELECT home_body FROM cms_content");

    while($row = mysql_fetch_array($sql)) { 
          $home_body = $row["home_body"];
          print "home_text=$home_body";
    }
}
//////////////////////////////////////////////// Update Home Page Text ///////////////////////////////////////////////////////////////////
if ($_POST['sendRequest'] == "update_home_page") {

    $home_body = $_POST['home_body'];
    $sql = mysql_query("UPDATE cms_content SET home_body='$home_body'");

}
//////////////////////////////////////////////// Gather About Page Text ///////////////////////////////////////////////////////////////////
if ($_POST['sendRequest'] == "get_about_text") {

    $sql = mysql_query("SELECT about_body FROM cms_content");

    while($row = mysql_fetch_array($sql)) { 
          $about_body = $row["about_body"];
          print "about_text=$about_body";
    }
}
//////////////////////////////////////////////// Update About Page Text ///////////////////////////////////////////////////////////////////
if ($_POST['sendRequest'] == "update_about_page") {

    $about_body = $_POST['about_body'];
    $sql = mysql_query("UPDATE cms_content SET about_body='$about_body'");

}
?>