-- phpMyAdmin SQL Dump
-- version 2.11.9.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 12, 2009 at 12:29 AM
-- Server version: 5.0.83
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `fightfor_aresp`
--

-- --------------------------------------------------------

--
-- Table structure for table `x_invitations`
--

CREATE TABLE IF NOT EXISTS `x_invitations` (
  `seml` varchar(200) NOT NULL,
  `feml` varchar(200) NOT NULL,
  `snam` varchar(50) NOT NULL,
  `fnam` varchar(50) NOT NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `cbcode` varchar(10) NOT NULL,
  `visitcounted` varchar(1) NOT NULL default 'N',
  PRIMARY KEY  (`seml`,`feml`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Email invitations';
