<?php
//Functions included in this file
//function to establish a connection to MySQL and selecting a database to work
function dbconnect()
{
	global $siteadds,$dbhost,$dbname,$dbuser,$dbpwd;
	if($link = mysql_connect($dbhost,$dbuser,$dbpwd))
	{
		$res=mysql_select_db($dbname) or die(mysql_error());
		if($res)
			return $link;
	}
	else
		print "There is some internal error in retrieving the records. Sorry for the inconvinence.";
}
//function  to close the opened link
function dbclose($link)
{
	global $link;
	if(mysql_close($link))
	{}
}

//Is email valid?
function isValidEmail($email){
	return eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$", $email);
}

//Validate the data posted for invite friend application
function validate_post()
{
	$msgToReturn = "";
	//Check security code
  if(($_SESSION['security_code'] == $_POST['security_code']) && (!empty($_SESSION['security_code'])) ) 
	{
		unset($_SESSION['security_code']);
	}
	else 
	{
		$msgToReturn .= "<p>ERROR! Security code is invalid. Try again.";
	}
	//Check if all fields are entered
	if($_POST['un'] == "" or $_POST['ue'] == "" or $_POST['fn'] == "" or $_POST['fe'] == "")
	{
		$msgToReturn .= "<p>ERROR! All fields must be entered. Try again.";
	} 
	
	//Check if emails are valid
	if(isValidEmail($_POST['ue']) and isValidEmail($_POST['fe']))
	{
	
	}
	else
	{
		$msgToReturn .= "<p>ERROR! Your or your friend's email is invalid. Try again.";
	}
	return $msgToReturn;

}

function send_mail_plain_new($mailid,$fromid,$replyto,$sub,$msg)
{
	global $def_eml_ad;
	//print "$mailid,$fromid,$sub,$msg";
  $headers  = "MIME-Version: 1.0\r\n";
  $headers .= "Content-type: text/plain; charset=iso-8859-1\r\n";
  /* additional headers */
  $headers .= "From: $replyto <$fromid>\r\n";
  $headers .= "Reply-To: $replyto\r\n";
	$msg="$msg".$def_eml_ad;
	//this will send mail to each person individually.
	$mailid=split(",",$mailid);
  for($i=0;$i<count($mailid);$i++)
  {
  	//echo"Message : $msg";
    if(mail($mailid[$i], $sub, $msg,$headers))
  	{
  	}
  	else
  	{
  		print "<br>Error sending email to $mailid[$i]";
  		exit;
  	}
 	}
  return 1;
}

?>