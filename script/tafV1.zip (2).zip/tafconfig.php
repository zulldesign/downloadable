<?php
$dbhost = "";   //Host of the DataBase
$dbname = "";   //DB Name
$dbuser = "";   //DB user name
$dbpwd = "";    //DB user password

$baseurl = "";  //Base URL of your website. Do not forget the trailing '/'. Example - http://www.yourdomain.com/
$taffolder = ""; //Web-Folder on your webserver where the application files are uploaded. Something like 'invitefriend/' Do not forget the trailing '/'
$sitename= "";  //Name of your site
$admin_email = "";  //Adminstrator email - this will never be shared with anyone
$noreply_email = ""; //This email will be used to send out invites - use something like noreply@yourdomain.com. This email must have your domain name otherwise emails will not go. This is a security feature. Don't worry, sender's email address will be added as 'Reply-to' address and will receive replies directly.

//This is the URL that will be sent in invitation mails. Do not change it if you wish to track the clicks
$invitationurl = $baseurl . $taffolder . "/tafvisit.php?r=[USER_EMAIL]&code=[CBCODE]";

//Default Message text sent in invitations 
$msgtxt = <<<TXT
Hi [FRIEND_NAME]!

THIS IS NOT SPAM! THIS IS AN INVITATION EMAIL FROM YOUR FRIEND TO VISIT $invitationurl 

[USER_NAME] thought that you would like this site and what it has to offer. 

Visit this link - $invitationurl

Thanks
Site Admin and [USER_NAME]
$siteurl
TXT;

//URL where the visitor will be sent after they click on the link in invitation email
$invitation_target = ""; //This is usually the main page of your site but you can direct the user to any other page. Do not forget to give the path from the base folder of your site. For example to redirect the user to the main page of your site you need to enter '/index.php' (assuming that index.php is the main page). Similarly you can also enter full path starting with http://. 

//DO NOT CHANGE ANYTHING BELOW THIS LINE - AS PER TERMS OF LICENSE
$def_eml_ad = <<<TXT

-----------------------------------------
This email is sent by Tell-a-Friend script developed by http://www.monitor-line.com. Visit us for great webmaster resources.


TXT;


?>