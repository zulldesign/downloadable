<?
//This is header file you can add your own footer code
?>
<h2 align="center">Thank you for using TAF V1 demo. We hope you liked it!</h2>
<!-- Please do not remove the following link. It is required as per license terms -->
<hr size="1">
<p align="center"><font size="2">This script is powered by <a href="http://www.monitor-line.com" target="_blank">Monitor-Line Scripts and Webmaster Resources</a></font></p>
