<?
include_once("tafconfig.php");
include_once("taffuns.php");
global $noreply_email, $link, $msgtxt, $sitename, $invitation_target;
$link = dbconnect();
$re=$HTTP_GET_VARS['r'];
if($re!="")
{
	//Track the clicks
	$tc = $HTTP_GET_VARS['code'];
	if($tc!="")
	{
		$q="UPDATE x_invitations SET visitcounted = 'Y' WHERE cbcode = '$tc' AND seml = '$re'";
		if($r=mysql_query($q))
		{
			//Add code here if you want to do further processing at this point
			
		}
	}
}
header("Location: $invitation_target");
dbclose($link);
?>