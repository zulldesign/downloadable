<?
header("Location: invite_friends.php");
?>
