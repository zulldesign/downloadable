<?
//This is header file you can add your own footer code

?>
<h2 align="center">Welcome to Tell-a-Friend (TAF) V1!</h2>

