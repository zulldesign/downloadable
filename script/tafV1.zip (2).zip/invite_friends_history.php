<?
include_once("tafconfig.php");
include_once("taffuns.php");
global $noreply_email, $link;

$link = dbconnect();
$pageErrorMsg = "";
$pageSuccessMsg = "";
session_start();
$link = dbconnect();

if(count($_POST)>0)
{
	if($_POST['ue'] == "" or $_POST['security_code'] == "")
	{
		$pagecontent .= "<p>ERROR! All fields are necessary. Try again.";
	}
	
	//Check security code
  if(($_SESSION['security_code'] == $_POST['security_code']) && (!empty($_SESSION['security_code'])) ) 
	{
		unset($_SESSION['security_code']);
	}
	else 
	{
		$pagecontent .= "<p>ERROR! Security code is invalid. Try again.";
	}
	
	if($pagecontent == "")
	{
		$eml = $_POST['ue'];
		$q="SELECT * FROM x_invitations WHERE seml = '$eml'";
		if($r=mysql_query($q))
		{
			$pagecontent .= <<<HTM
				<table border="1" cellpadding="5" cellspacing="0" summary="" align="center" width="90%">
					<tr bgcolor="#003366">
						<td align="center" valign="top">
							<font color="#ffffff"><b>Invitee's name</b></font>
						</td>
						<td align="center" valign="top">
							<font color="#ffffff"><b>Time of invitation</b></font>
						</td>
						<td align="center" valign="top">
							<font color="#ffffff"><b>Visit Recorded?</b></font>
						</td>
					</tr>
					
HTM;
			while($idata=mysql_fetch_array($r))
			{
				$fname = $idata['fnam'];
				$vtime = $idata['timestamp'];
				$vcounted = $idata['visitcounted'];
				
				$pagecontent .= <<<HTM
					<tr>
						<td align="center" valign="top">
							$fname
						</td>
						<td align="center" valign="top">
							$vtime
						</td>
						<td align="center" valign="top">
							$vcounted
						</td>
					</tr>
HTM;
			}
			$pagecontent .= "</table>";
		}
	}
}
else
{
	$pagecontent .= <<<HTM
		<P align=center><font face="Arial Black" size="3" color="#006699">Enter the details in the form below:</font></P>
		<form action="invite_friends_history.php" method="post">
  		<p>Your email you have used to invite friends: <input type="text" size="50" maxlength="200" name="ue" value="$uem"></p>
  		<p>Security Code -> <img src="CaptchaSecurityImages.php" /><br>
  		Enter Security Code: <input id="security_code" name="security_code" type="text" /></p>
  		<p><input type="submit" value="Show Invitations History"></p>
		</form>

HTM;
}
		

?>
<html>
<head>
<title><? echo $sitename; ?> - Invite friends history report</title>
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="Report of how many people you invited to visit our site and their current status. ">
<STYLE>
body {
	background-color:#999999;
	font-family:Verdana, Arial, Helvetica, sans-serif;
	font-size:12px;
	margin-top:0;
	margin-bottom:0;
	color:#333;
}
td {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
	border-bottom-width: medium;
	border-bottom-style: none;
	color:#333;
}



</style>


</head>
<body>
  <table border="0" cellpadding="10" cellspacing="0" summary="" bgcolor="#ffffff" width="800" align="center">
  	<tr>
  		<td colspan="3">
  			<? include("tafheader.php"); ?>
  		</td>
  	</tr>
  	<tr>
  		<td align="center" valign="top" width="10">
			</td>
			<td valign="top">
			  <span style="background-color: #ff0033;"><font color="#ffffff"><? echo $pageErrorMsg; ?></font></span>
				<span style="background-color: #009900;"><font color="#ffffff"><? echo $pageSuccessMsg; ?></font></span>
				<br>
				<P align=center><FONT face="Arial Black" color=#00256e size=5>Invite Friends History Report</FONT></P>
				<? echo $pagecontent; ?>

  		</td>
			<td align="center" valign="top" width="10">
			</td>
  	</tr>
  	<tr>
  		<td colspan="3">
  			<? include("taffooter.php"); ?>
  		</td>
  	</tr>
  </table>
</body>
</html>
<?
dbclose($link);
?>