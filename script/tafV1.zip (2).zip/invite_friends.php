<?
include_once("tafconfig.php");
include_once("taffuns.php");
global $noreply_email, $link, $msgtxt, $sitename;
$link = dbconnect();


		$cbcode=rand(0,9);
  	$cbcode.=rand(0,9);
  	$cbcode.=rand(0,9);
  	$cbcode.=rand(0,9);
  	$cbcode.=rand(0,9);
  	$cbcode.=rand(0,9);
  	$cbcode.=rand(0,9);
  	$cbcode.=rand(0,9);
  	$cbcode.=rand(0,9);
  	$cbcode.=rand(0,9);
		
$pageErrorMsg = "";
$pageSuccessMsg = "";
session_start();
//Replace the code
$msgtxt = str_replace("[CBCODE]", $cbcode, $msgtxt);
//Name of the sender
$una = $HTTP_POST_VARS['un'];
if(isset($una))
{
	$msgtxt = str_replace("[USER_NAME]", $una, $msgtxt);
}
//Email of the sender
$uem = $HTTP_POST_VARS['ue'];
if(isset($uem))
{
	$msgtxt = str_replace("[USER_EMAIL]", $uem, $msgtxt);
}
//Name of the sender
$fna = $HTTP_POST_VARS['fn'];
if(isset($fna))
{
	$msgtxt = str_replace("[FRIEND_NAME]", $fna, $msgtxt);
}
//Email of the friend
$fem = $HTTP_POST_VARS['fe'];

if(count($_POST))
{
	$pageErrorMsg.=validate_post();
  if($pageErrorMsg=="")
  {
		//Insert into the invitations table
		$seml = $_POST['ue'];
		$feml = $_POST['fe'];
		$snam = $_POST['un'];
		$fnam = $_POST['fn'];
		
		$q="INSERT INTO x_invitations SET seml = '$seml', feml = '$feml', snam = '$snam', fnam = '$fnam', cbcode = '$cbcode' ON DUPLICATE KEY UPDATE snam = '$snam', fnam = '$fnam', cbcode = '$cbcode'"; 
		mysql_query($q);
		
		$emailstosend = $_POST['fe'];
		//If admin wants a copy of the mail, add admin email to the recepients
		if($copytoadmin == 1)
		{
			$emailstosend = $emailstosend . "," . $admin_email;
		}
		
  	if(send_mail_plain_new($emailstosend,$noreply_email,$_POST['ue'],$sitename . " invitation from " . $_POST['un'],$msgtxt))
		{
			$pageSuccessMsg = "SUCCESS! Mail sent successfully! Use the form below to invite more friends and family.";
			//See if total of minimum required invites are sent successfully to give access to the book
			$q1="SELECT COUNT( * ) FROM x_invitations WHERE seml = '$seml'";
			if($r1=mysql_query($q1))
			{
				$sdata=mysql_fetch_array($r1);
				$pageSuccessMsg .= "<br>You have sent total of $sdata[0] invitations so far.";				
			}			
		}
  }
}


?>
<html>
<head>
<title><? echo $sitename; ?> - Invite your friends and family to visit our site</title>
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="Invite your friends and family to visit our site.">
<STYLE>
body {
	background-color:#999999;
	font-family:Verdana, Arial, Helvetica, sans-serif;
	font-size:12px;
	margin-top:0;
	margin-bottom:0;
	color:#333;
}
td {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
	border-bottom-width: medium;
	border-bottom-style: none;
	color:#333;
}



</style>


</head>
<body>
  <table border="0" cellpadding="10" cellspacing="0" summary="" bgcolor="#ffffff" width="800" align="center">
  	<tr>
  		<td colspan="3">
  			<? include("tafheader.php"); ?>
  		</td>
  	</tr>
  	<tr>
  		<td align="center" valign="top" width="10">
			</td>
			<td valign="top">
			  <span style="background-color: #ff0033;"><font color="#ffffff"><? echo $pageErrorMsg; ?></font></span>
				<span style="background-color: #009900;"><font color="#ffffff"><? echo $pageSuccessMsg; ?></font></span>
				<br>
				<P align=center><FONT face="Arial Black" color=#00256e size=5>Invite Your Friends and Family</FONT></P>
				<P align=center><FONT face="Arial" size=1>(If you have already invited friends/family, check what happened to your invites here - <a href="invite_friends_history.php">Invitations History</a>)</FONT></P>
				
				<P align=center><font face="Arial Black" size="3" color="#006699">Enter the details in the form below:</font></P>
				<form action="invite_friends.php" method="post">
					<p>Your name: <input type="text" size="30" maxlength="50" name="un" value="<? echo $una; ?>"></p>
					<p>Your email: <input type="text" size="50" maxlength="200" name="ue" value="<? echo $uem; ?>"></p>
					<p>Name of your friend: <input type="text" size="30" maxlength="50" name="fn" value="<? echo $fna; ?>"></p>
					<p>Email of your friend: <input type="text" size="50" maxlength="200" name="fe" value="<? echo $fem; ?>"></p>
					<p>Message text that will be sent to your friend: <font size="1">(Note that [FRIEND_NAME] will be replaced with your friend's name, [USER_NAME] will be replaced with your name and [USER_EMAIL] will be replaced with your email before the message is sent.)</font></p>
					<textarea name="et" rows="20" cols="90" disabled="disabled">
<? echo $msgtxt; ?> 
</textarea>
					<p>Security Code -> <img src="CaptchaSecurityImages.php" /><br>
					Enter Security Code: <input id="security_code" name="security_code" type="text" /></p>
					
					<p><input type="submit" value="Send Invitation!"></p>
					
				</form>
				

  		</td>
			<td align="center" valign="top" width="10">
			</td>
  	</tr>
  	<tr>
  		<td colspan="3">
  			<? include("taffooter.php"); ?>
  		</td>
  	</tr>
  </table>
</body>
</html>
<?
dbclose($link);
?>