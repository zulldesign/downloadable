<?php

if ($_POST['requestCode'] == "add1") {

$txtDatabase = "flash_hit_count.txt";

$currentNumber = file_get_contents($txtDatabase, true);

$fh = fopen($txtDatabase, 'w') or die ("cannot open file");
$newNumber = $currentNumber + 1;
$data = "$newNumber";
fwrite($fh, $data);
fclose($fh);

// Print the new number back to flash now
print "phpCountVar=$newNumber";

}

?>